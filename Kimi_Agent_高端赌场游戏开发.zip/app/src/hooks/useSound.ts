import { useCallback } from 'react';

// Game-specific sound effects using reliable sources
const SOUND_URLS = {
  // UI Sounds
  click: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
  hover: 'https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3',
  
  // Card Sounds
  cardDeal: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
  cardFlip: 'https://assets.mixkit.co/active_storage/sfx/2572/2572-preview.mp3',
  cardShuffle: 'https://assets.mixkit.co/active_storage/sfx/2578/2578-preview.mp3',
  
  // Chip/Bet Sounds
  chipStack: 'https://assets.mixkit.co/active_storage/sfx/2570/2570-preview.mp3',
  chipSingle: 'https://assets.mixkit.co/active_storage/sfx/2577/2577-preview.mp3',
  
  // Win/Lose Sounds
  winSmall: 'https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3',
  winBig: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
  lose: 'https://assets.mixkit.co/active_storage/sfx/1432/1432-preview.mp3',
  cashout: 'https://assets.mixkit.co/active_storage/sfx/2003/2003-preview.mp3',
  
  // Game Specific
  rouletteSpin: 'https://assets.mixkit.co/active_storage/sfx/2044/2044-preview.mp3',
  rouletteBall: 'https://assets.mixkit.co/active_storage/sfx/2574/2574-preview.mp3',
  crashTick: 'https://assets.mixkit.co/active_storage/sfx/2573/2573-preview.mp3',
  crashExplosion: 'https://assets.mixkit.co/active_storage/sfx/2561/2561-preview.mp3',
  plinkoDrop: 'https://assets.mixkit.co/active_storage/sfx/2574/2574-preview.mp3',
  plinkoBounce: 'https://assets.mixkit.co/active_storage/sfx/2575/2575-preview.mp3',
  mineReveal: 'https://assets.mixkit.co/active_storage/sfx/2576/2576-preview.mp3',
  mineExplosion: 'https://assets.mixkit.co/active_storage/sfx/2561/2561-preview.mp3',
  gemFound: 'https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3',
  
  // Blackjack Specific
  blackjack: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
  bust: 'https://assets.mixkit.co/active_storage/sfx/2561/2561-preview.mp3',
  push: 'https://assets.mixkit.co/active_storage/sfx/2003/2003-preview.mp3',
  insurance: 'https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3',
  
  // Limbo/HiLo
  tick: 'https://assets.mixkit.co/active_storage/sfx/2573/2573-preview.mp3',
  reveal: 'https://assets.mixkit.co/active_storage/sfx/2575/2575-preview.mp3',
};

type SoundName = keyof typeof SOUND_URLS;

// Audio cache
const audioCache: Map<string, HTMLAudioElement> = new Map();

export const useSound = () => {
  // Preload audio
  const preloadSound = useCallback((soundName: SoundName) => {
    if (!audioCache.has(soundName)) {
      const audio = new Audio(SOUND_URLS[soundName]);
      audio.preload = 'auto';
      audioCache.set(soundName, audio);
    }
  }, []);

  // Play sound
  const playSound = useCallback((soundName: SoundName, volume: number = 0.4) => {
    try {
      // Check if sound is enabled
      const soundEnabled = localStorage.getItem('blackout_sound_enabled') !== 'false';
      if (!soundEnabled) return;

      let audio = audioCache.get(soundName);
      if (!audio) {
        audio = new Audio(SOUND_URLS[soundName]);
        audioCache.set(soundName, audio);
      }
      
      // Clone audio for overlapping sounds
      const audioClone = audio.cloneNode() as HTMLAudioElement;
      audioClone.volume = volume;
      audioClone.currentTime = 0;
      
      const playPromise = audioClone.play();
      if (playPromise) {
        playPromise.catch(() => {
          // Ignore autoplay errors
        });
      }
    } catch {
      // Ignore sound errors
    }
  }, []);

  // Toggle sound
  const toggleSound = useCallback(() => {
    const current = localStorage.getItem('blackout_sound_enabled') !== 'false';
    localStorage.setItem('blackout_sound_enabled', String(!current));
    return !current;
  }, []);

  // Check if sound is enabled
  const isSoundEnabled = useCallback(() => {
    return localStorage.getItem('blackout_sound_enabled') !== 'false';
  }, []);

  // Game-specific sound helpers
  const playCardSound = useCallback(() => playSound('cardDeal', 0.3), [playSound]);
  const playFlipSound = useCallback(() => playSound('cardFlip', 0.3), [playSound]);
  const playChipSound = useCallback(() => playSound('chipStack', 0.4), [playSound]);
  const playWinSound = useCallback((big: boolean = false) => playSound(big ? 'winBig' : 'winSmall', 0.5), [playSound]);
  const playLoseSound = useCallback(() => playSound('lose', 0.4), [playSound]);
  const playCashoutSound = useCallback(() => playSound('cashout', 0.5), [playSound]);
  const playClickSound = useCallback(() => playSound('click', 0.2), [playSound]);
  const playRouletteSpin = useCallback(() => playSound('rouletteSpin', 0.4), [playSound]);
  const playCrashTick = useCallback(() => playSound('crashTick', 0.2), [playSound]);
  const playCrashExplosion = useCallback(() => playSound('crashExplosion', 0.5), [playSound]);
  const playPlinkoBounce = useCallback(() => playSound('plinkoBounce', 0.3), [playSound]);
  const playMineReveal = useCallback(() => playSound('mineReveal', 0.3), [playSound]);
  const playMineExplosion = useCallback(() => playSound('mineExplosion', 0.5), [playSound]);
  const playGemFound = useCallback(() => playSound('gemFound', 0.4), [playSound]);
  const playBlackjack = useCallback(() => playSound('blackjack', 0.6), [playSound]);
  const playBust = useCallback(() => playSound('bust', 0.5), [playSound]);
  const playCrashSound = useCallback(() => playSound('crashExplosion', 0.5), [playSound]);

  return {
    playSound,
    toggleSound,
    isSoundEnabled,
    preloadSound,
    // Game-specific shortcuts
    playCardSound,
    playFlipSound,
    playChipSound,
    playWinSound,
    playLoseSound,
    playCashoutSound,
    playClickSound,
    playRouletteSpin,
    playCrashTick,
    playCrashExplosion,
    playPlinkoBounce,
    playMineReveal,
    playMineExplosion,
    playGemFound,
    playBlackjack,
    playBust,
    playCrashSound,
  };
};

export default useSound;
