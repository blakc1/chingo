import { useState } from 'react';
import { Headphones, Mail, MessageCircle, Send, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

export const Support = () => {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setSubject('');
      setMessage('');
    }, 3000);
  };

  return (
    <div className="max-w-3xl mx-auto py-6">
      <div className="flex items-center gap-3 mb-6">
        <Headphones className="w-8 h-8 text-[#00e701]" />
        <h1 className="text-3xl font-bold text-white">Support</h1>
      </div>

      {/* Contact Options */}
      <div className="grid md:grid-cols-2 gap-4 mb-6">
        <div className="bg-[#1a2c38] rounded-xl p-5 border border-[#2f4553]">
          <Mail className="w-6 h-6 text-[#00e701] mb-3" />
          <h3 className="text-white font-bold mb-1">Email Support</h3>
          <p className="text-[#b1bad3] text-sm mb-2">support@blackout.casino</p>
          <p className="text-[#557086] text-xs">Response within 24 hours</p>
        </div>
        <div className="bg-[#1a2c38] rounded-xl p-5 border border-[#2f4553]">
          <MessageCircle className="w-6 h-6 text-[#00e701] mb-3" />
          <h3 className="text-white font-bold mb-1">Live Chat</h3>
          <p className="text-[#b1bad3] text-sm mb-2">Available 24/7</p>
          <p className="text-[#557086] text-xs">Instant responses</p>
        </div>
      </div>

      {/* Contact Form */}
      <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553]">
        <h2 className="text-white font-bold text-lg mb-4">Send us a message</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[#b1bad3] text-sm mb-2 block">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="What's this about?"
              className="w-full px-4 py-3 bg-[#0f1923] border border-[#2f4553] rounded-lg text-white placeholder-[#557086] focus:outline-none focus:border-[#00e701] transition-colors"
              required
            />
          </div>
          <div>
            <label className="text-[#b1bad3] text-sm mb-2 block">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Describe your issue or question..."
              rows={5}
              className="w-full px-4 py-3 bg-[#0f1923] border border-[#2f4553] rounded-lg text-white placeholder-[#557086] focus:outline-none focus:border-[#00e701] transition-colors resize-none"
              required
            />
          </div>
          <button
            type="submit"
            disabled={submitted}
            className={cn(
              "w-full py-3 rounded-lg font-bold transition-all flex items-center justify-center gap-2",
              submitted
                ? "bg-[#00e701] text-black"
                : "bg-[#00e701] hover:bg-[#00c701] text-black"
            )}
          >
            {submitted ? (
              <>
                <Check className="w-4 h-4" />
                Message Sent!
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Send Message
              </>
            )}
          </button>
        </form>
      </div>

      {/* FAQ */}
      <div className="mt-6 bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553]">
        <h2 className="text-white font-bold text-lg mb-4">Frequently Asked Questions</h2>
        <div className="space-y-4">
          <div>
            <h3 className="text-white font-medium mb-1">How do I claim my daily bonus?</h3>
            <p className="text-[#b1bad3] text-sm">Visit the Daily Bonus page every 24 hours to claim your free Gold Coins and BlackoutCash.</p>
          </div>
          <div>
            <h3 className="text-white font-medium mb-1">What is the minimum withdrawal?</h3>
            <p className="text-[#b1bad3] text-sm">The minimum withdrawal amount is $50.00 in BlackoutCash.</p>
          </div>
          <div>
            <h3 className="text-white font-medium mb-1">How long do withdrawals take?</h3>
            <p className="text-[#b1bad3] text-sm">Withdrawals are typically processed within 24-48 hours.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
