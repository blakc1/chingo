import { useState } from 'react';
import { useGameStore, PURCHASE_PACKAGES } from '@/store/GameStore';
import { Check, Star, Shield, CreditCard, Bitcoin } from 'lucide-react';
import { cn } from '@/lib/utils';

export const Purchase = () => {
  const { purchasePackage } = useGameStore();
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [purchased, setPurchased] = useState(false);

  const handlePurchase = (packageId: string) => {
    if (purchasePackage(packageId)) {
      setSelectedPackage(packageId);
      setPurchased(true);
      setTimeout(() => {
        setPurchased(false);
        setSelectedPackage(null);
      }, 3000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-6">
      <h1 className="text-3xl font-bold text-white mb-2">Purchase Gold Coins</h1>
      <p className="text-[#b1bad3] mb-6">Get Gold Coins and receive FREE BlackoutCash with every purchase!</p>

      {/* Packages Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {PURCHASE_PACKAGES.map((pkg) => (
          <div
            key={pkg.id}
            className={cn(
              "relative bg-[#1a2c38] rounded-xl p-5 border transition-all cursor-pointer",
              pkg.popular 
                ? "border-[#00e701] ring-1 ring-[#00e701]/30" 
                : "border-[#2f4553] hover:border-[#3f5563]"
            )}
          >
            {pkg.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#00e701] text-black text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                <Star className="w-3 h-3" />
                MOST POPULAR
              </div>
            )}

            <div className="text-center mb-4">
              <h3 className="text-white font-bold text-lg">{pkg.name}</h3>
              <p className="text-[#557086] text-sm">${pkg.price.toFixed(2)}</p>
            </div>

            <div className="space-y-3 mb-5">
              <div className="flex items-center justify-between">
                <span className="text-[#b1bad3] text-sm">Gold Coins</span>
                <span className="text-[#fbbf24] font-bold font-mono">{pkg.goldCoins.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#b1bad3] text-sm">BlackoutCash Bonus</span>
                <span className="text-[#00e701] font-bold font-mono">${pkg.blackoutCashBonus.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => handlePurchase(pkg.id)}
              disabled={purchased && selectedPackage === pkg.id}
              className={cn(
                "w-full py-3 rounded-lg font-bold transition-all",
                purchased && selectedPackage === pkg.id
                  ? "bg-[#00e701] text-black"
                  : "bg-[#00e701] hover:bg-[#00c701] text-black"
              )}
            >
              {purchased && selectedPackage === pkg.id ? (
                <span className="flex items-center justify-center gap-2">
                  <Check className="w-4 h-4" />
                  Purchased!
                </span>
              ) : (
                `Buy $${pkg.price}`
              )}
            </button>
          </div>
        ))}
      </div>

      {/* Payment Methods */}
      <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553]">
        <h2 className="text-white font-bold mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-[#00e701]" />
          Secure Payment Methods
        </h2>
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2 bg-[#0f1923] px-4 py-2 rounded-lg">
            <CreditCard className="w-5 h-5 text-[#b1bad3]" />
            <span className="text-[#b1bad3] text-sm">Credit Card</span>
          </div>
          <div className="flex items-center gap-2 bg-[#0f1923] px-4 py-2 rounded-lg">
            <Bitcoin className="w-5 h-5 text-[#fbbf24]" />
            <span className="text-[#b1bad3] text-sm">Crypto</span>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="mt-6 text-[#557086] text-sm">
        <p>Gold Coins are for entertainment purposes only and cannot be redeemed for cash.</p>
        <p className="mt-1">BlackoutCash can be used to play games and redeemed for prizes when you win.</p>
      </div>
    </div>
  );
};
