import { Scale } from 'lucide-react';

export const Terms = () => {
  return (
    <div className="max-w-3xl mx-auto py-6">
      <div className="flex items-center gap-3 mb-6">
        <Scale className="w-8 h-8 text-[#00e701]" />
        <h1 className="text-3xl font-bold text-white">Terms of Service</h1>
      </div>

      <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553] space-y-6 text-[#b1bad3]">
        <section>
          <h2 className="text-white font-bold text-lg mb-2">1. Acceptance of Terms</h2>
          <p>By accessing and using Blackout Casino, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, you may not use our services.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">2. Eligibility</h2>
          <p>You must be at least 18 years old to use our services. By using Blackout Casino, you represent and warrant that you meet this requirement.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">3. Sweepstakes Model</h2>
          <p>Blackout Casino operates on a sweepstakes model. Gold Coins are for entertainment purposes only and have no monetary value. BlackoutCash can be redeemed for prizes according to our sweepstakes rules.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">4. Account Security</h2>
          <p>You are responsible for maintaining the confidentiality of your account credentials. Notify us immediately of any unauthorized use of your account.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">5. Prohibited Activities</h2>
          <p>Users may not use automated systems, bots, or scripts to interact with our platform. Any attempt to manipulate game outcomes is strictly prohibited.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">6. Limitation of Liability</h2>
          <p>Blackout Casino is not liable for any damages arising from your use of our services. All games are provided as-is.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">7. Changes to Terms</h2>
          <p>We reserve the right to modify these terms at any time. Continued use of our services constitutes acceptance of the updated terms.</p>
        </section>
      </div>
    </div>
  );
};
