import { useState, useEffect } from 'react';
import { useGameStore, DAILY_BONUS_COINS, DAILY_BONUS_CASH } from '@/store/GameStore';
import { Gift, Coins, DollarSign, Check, Sparkles, Calendar, Timer } from 'lucide-react';
import { cn } from '@/lib/utils';

export const DailyBonus = () => {
  const { dailyBonus, claimDailyBonus, dailyBonusTimeLeft } = useGameStore();
  const [claimed, setClaimed] = useState(false);
  const [countdown, setCountdown] = useState('');

  // Live countdown timer
  useEffect(() => {
    const updateCountdown = () => {
      if (dailyBonusTimeLeft <= 0) {
        setCountdown('00:00:00');
        return;
      }

      const hours = Math.floor(dailyBonusTimeLeft / (1000 * 60 * 60));
      const minutes = Math.floor((dailyBonusTimeLeft % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((dailyBonusTimeLeft % (1000 * 60)) / 1000);

      setCountdown(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [dailyBonusTimeLeft]);

  const handleClaim = () => {
    if (claimDailyBonus()) {
      setClaimed(true);
      setTimeout(() => setClaimed(false), 3000);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#00e701] to-[#00c701] rounded-2xl mb-4 shadow-lg">
          <Gift className="w-10 h-10 text-black" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-2">Daily Bonus</h1>
        <p className="text-[#b1bad3]">Claim your free rewards every 24 hours!</p>
      </div>

      {/* Rewards */}
      <div className="grid md:grid-cols-2 gap-4 mb-6">
        <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-[#fbbf24] rounded-xl flex items-center justify-center">
              <Coins className="w-6 h-6 text-black" />
            </div>
            <div>
              <p className="text-[#b1bad3] text-sm">Gold Coins</p>
              <p className="text-white font-bold">Free Play Money</p>
            </div>
          </div>
          <p className="text-4xl font-bold text-[#fbbf24]">{DAILY_BONUS_COINS.toLocaleString()}</p>
        </div>

        <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-[#00e701] rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-black" />
            </div>
            <div>
              <p className="text-[#b1bad3] text-sm">BlackoutCash</p>
              <p className="text-white font-bold">Sweepstakes Cash</p>
            </div>
          </div>
          <p className="text-4xl font-bold text-[#00e701]">${DAILY_BONUS_CASH.toFixed(2)}</p>
        </div>
      </div>

      {/* Claim Button */}
      <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553] text-center">
        {dailyBonus.canClaim ? (
          <>
            <div className="flex items-center justify-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-[#00e701]" />
              <span className="text-[#00e701] font-bold text-lg">Bonus Available!</span>
              <Sparkles className="w-6 h-6 text-[#00e701]" />
            </div>
            <button
              onClick={handleClaim}
              disabled={claimed}
              className={cn(
                "bg-[#00e701] hover:bg-[#00c701] text-black font-bold text-lg px-12 py-4 rounded-xl transition-all",
                claimed && "opacity-70"
              )}
            >
              {claimed ? (
                <span className="flex items-center gap-2">
                  <Check className="w-5 h-5" />
                  Claimed!
                </span>
              ) : (
                'Claim Daily Bonus'
              )}
            </button>
          </>
        ) : (
          <>
            <div className="flex items-center justify-center gap-2 mb-4">
              <Timer className="w-6 h-6 text-[#557086]" />
              <span className="text-[#b1bad3] font-bold text-lg">Next Bonus In</span>
            </div>
            <div className="text-5xl font-mono font-bold text-white mb-2">
              {countdown}
            </div>
            <div className="w-full h-2 bg-[#0f1923] rounded-full overflow-hidden mt-4">
              <div
                className="h-full bg-[#00e701] transition-all duration-1000"
                style={{ width: `${((24 * 60 * 60 * 1000 - dailyBonusTimeLeft) / (24 * 60 * 60 * 1000)) * 100}%` }}
              />
            </div>
          </>
        )}
      </div>

      {/* How It Works */}
      <div className="mt-6 bg-[#1a2c38]/50 rounded-xl p-6 border border-[#2f4553]/50">
        <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-[#00e701]" />
          How It Works
        </h3>
        <ul className="space-y-3 text-[#b1bad3] text-sm">
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 bg-[#00e701] rounded-full flex items-center justify-center text-black text-sm font-bold flex-shrink-0">1</span>
            <span>Log in every 24 hours to claim your free bonus</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 bg-[#00e701] rounded-full flex items-center justify-center text-black text-sm font-bold flex-shrink-0">2</span>
            <span>Get {DAILY_BONUS_COINS.toLocaleString()} Gold Coins to play any game</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 bg-[#00e701] rounded-full flex items-center justify-center text-black text-sm font-bold flex-shrink-0">3</span>
            <span>Receive ${DAILY_BONUS_CASH.toFixed(2)} BlackoutCash sweepstakes cash</span>
          </li>
        </ul>
      </div>
    </div>
  );
};
