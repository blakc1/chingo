import { Shield } from 'lucide-react';

export const Privacy = () => {
  return (
    <div className="max-w-3xl mx-auto py-6">
      <div className="flex items-center gap-3 mb-6">
        <Shield className="w-8 h-8 text-[#00e701]" />
        <h1 className="text-3xl font-bold text-white">Privacy Policy</h1>
      </div>

      <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553] space-y-6 text-[#b1bad3]">
        <section>
          <h2 className="text-white font-bold text-lg mb-2">1. Information We Collect</h2>
          <p>We collect information you provide directly to us, including your email address, username, and gameplay data. We also collect technical information such as your IP address and browser type.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">2. How We Use Your Information</h2>
          <p>We use your information to provide and improve our services, process transactions, communicate with you, and ensure the security of our platform.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">3. Data Security</h2>
          <p>We implement appropriate security measures to protect your personal information. However, no method of transmission over the internet is 100% secure.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">4. Cookies</h2>
          <p>We use cookies to enhance your experience on our platform. You can disable cookies in your browser settings, but this may affect functionality.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">5. Third-Party Services</h2>
          <p>We may use third-party services for analytics and payment processing. These services have their own privacy policies.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">6. Your Rights</h2>
          <p>You have the right to access, correct, or delete your personal information. Contact us to exercise these rights.</p>
        </section>

        <section>
          <h2 className="text-white font-bold text-lg mb-2">7. Changes to Privacy Policy</h2>
          <p>We may update this privacy policy from time to time. We will notify you of any significant changes.</p>
        </section>
      </div>
    </div>
  );
};
