import { useState } from 'react';
import { useGameStore, MIN_WITHDRAWAL } from '@/store/GameStore';
import { ArrowRightLeft, DollarSign, AlertCircle, Check, Bitcoin, Banknote } from 'lucide-react';
import { cn } from '@/lib/utils';

export const Withdrawal = () => {
  const { balance, requestWithdrawal } = useGameStore();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('crypto');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const withdrawalAmount = parseFloat(amount);
    if (isNaN(withdrawalAmount) || withdrawalAmount < MIN_WITHDRAWAL) {
      setError(`Minimum withdrawal is $${MIN_WITHDRAWAL.toFixed(2)}`);
      return;
    }
    if (withdrawalAmount > balance.blackout) {
      setError('Insufficient balance');
      return;
    }
    if (!details.trim()) {
      setError('Please enter withdrawal details');
      return;
    }

    if (requestWithdrawal(withdrawalAmount, method, details)) {
      setSubmitted(true);
      setAmount('');
      setDetails('');
      setTimeout(() => setSubmitted(false), 3000);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-6">
      <h1 className="text-3xl font-bold text-white mb-2">Withdraw BlackoutCash</h1>
      <p className="text-[#b1bad3] mb-6">Redeem your BlackoutCash for real prizes!</p>

      {/* Balance */}
      <div className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553] mb-6">
        <p className="text-[#b1bad3] text-sm mb-1">Available Balance</p>
        <p className="text-4xl font-bold text-[#00e701] font-mono">${balance.blackout.toFixed(2)}</p>
        <p className="text-[#557086] text-sm mt-2">Minimum withdrawal: ${MIN_WITHDRAWAL.toFixed(2)}</p>
      </div>

      {/* Withdrawal Form */}
      <form onSubmit={handleSubmit} className="bg-[#1a2c38] rounded-xl p-6 border border-[#2f4553]">
        {/* Amount */}
        <div className="mb-4">
          <label className="text-[#b1bad3] text-sm mb-2 block">Amount</label>
          <div className="relative">
            <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#557086]" />
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              min={MIN_WITHDRAWAL}
              step="0.01"
              className="w-full pl-12 pr-4 py-3 bg-[#0f1923] border border-[#2f4553] rounded-lg text-white placeholder-[#557086] focus:outline-none focus:border-[#00e701] transition-colors"
            />
          </div>
        </div>

        {/* Method */}
        <div className="mb-4">
          <label className="text-[#b1bad3] text-sm mb-2 block">Withdrawal Method</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setMethod('crypto')}
              className={cn(
                "flex items-center gap-3 p-3 rounded-lg border transition-all",
                method === 'crypto'
                  ? "border-[#00e701] bg-[#00e701]/10"
                  : "border-[#2f4553] hover:border-[#3f5563]"
              )}
            >
              <Bitcoin className="w-5 h-5 text-[#fbbf24]" />
              <span className="text-white text-sm">Crypto</span>
            </button>
            <button
              type="button"
              onClick={() => setMethod('bank')}
              className={cn(
                "flex items-center gap-3 p-3 rounded-lg border transition-all",
                method === 'bank'
                  ? "border-[#00e701] bg-[#00e701]/10"
                  : "border-[#2f4553] hover:border-[#3f5563]"
              )}
            >
              <Banknote className="w-5 h-5 text-[#00e701]" />
              <span className="text-white text-sm">Bank Transfer</span>
            </button>
          </div>
        </div>

        {/* Details */}
        <div className="mb-4">
          <label className="text-[#b1bad3] text-sm mb-2 block">
            {method === 'crypto' ? 'Wallet Address' : 'Bank Account Details'}
          </label>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder={method === 'crypto' ? 'Enter your crypto wallet address...' : 'Enter your bank account details...'}
            rows={3}
            className="w-full px-4 py-3 bg-[#0f1923] border border-[#2f4553] rounded-lg text-white placeholder-[#557086] focus:outline-none focus:border-[#00e701] transition-colors resize-none"
          />
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 p-3 bg-[#ff4d4d]/10 border border-[#ff4d4d]/30 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-[#ff4d4d]" />
            <span className="text-[#ff4d4d] text-sm">{error}</span>
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={submitted}
          className={cn(
            "w-full py-3 rounded-lg font-bold transition-all flex items-center justify-center gap-2",
            submitted
              ? "bg-[#00e701] text-black"
              : "bg-[#00e701] hover:bg-[#00c701] text-black"
          )}
        >
          {submitted ? (
            <>
              <Check className="w-4 h-4" />
              Request Submitted!
            </>
          ) : (
            <>
              <ArrowRightLeft className="w-4 h-4" />
              Request Withdrawal
            </>
          )}
        </button>
      </form>

      {/* Info */}
      <div className="mt-6 text-[#557086] text-sm space-y-1">
        <p>Withdrawals are processed within 24-48 hours.</p>
        <p>You may be required to verify your identity before your first withdrawal.</p>
      </div>
    </div>
  );
};
