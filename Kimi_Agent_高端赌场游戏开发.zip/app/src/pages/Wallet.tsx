import { useGameStore } from '@/store/GameStore';
import { Coins, DollarSign, ArrowRightLeft, History, Gift, ShoppingCart } from 'lucide-react';
import { cn } from '@/lib/utils';

export const Wallet = () => {
  const { balance, transactions, setCurrentPage } = useGameStore();

  const recentTransactions = transactions.slice(0, 10);

  return (
    <div className="max-w-4xl mx-auto py-6">
      <h1 className="text-3xl font-bold text-white mb-6">Wallet</h1>

      {/* Balance Cards */}
      <div className="grid md:grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-br from-[#1a2c38] to-[#243b4d] rounded-xl p-6 border border-[#fbbf24]/30">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-[#fbbf24] rounded-xl flex items-center justify-center">
              <Coins className="w-6 h-6 text-black" />
            </div>
            <div>
              <p className="text-[#b1bad3] text-sm">Gold Coins</p>
              <p className="text-white font-bold">Play Money</p>
            </div>
          </div>
          <p className="text-4xl font-bold text-[#fbbf24] font-mono">{balance.gold.toLocaleString()}</p>
          <button 
            onClick={() => setCurrentPage('purchase')}
            className="mt-4 w-full py-2 bg-[#fbbf24] hover:bg-[#f59e0b] text-black font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-4 h-4" />
            Buy More
          </button>
        </div>

        <div className="bg-gradient-to-br from-[#1a2c38] to-[#243b4d] rounded-xl p-6 border border-[#00e701]/30">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-[#00e701] rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-black" />
            </div>
            <div>
              <p className="text-[#b1bad3] text-sm">BlackoutCash</p>
              <p className="text-white font-bold">Sweepstakes Cash</p>
            </div>
          </div>
          <p className="text-4xl font-bold text-[#00e701] font-mono">${balance.blackout.toFixed(2)}</p>
          <button 
            onClick={() => setCurrentPage('withdrawal')}
            className="mt-4 w-full py-2 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <ArrowRightLeft className="w-4 h-4" />
            Withdraw
          </button>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <button 
          onClick={() => setCurrentPage('dailybonus')}
          className="bg-[#1a2c38] hover:bg-[#243b4d] rounded-xl p-4 border border-[#2f4553] transition-colors text-center"
        >
          <Gift className="w-6 h-6 text-[#00e701] mx-auto mb-2" />
          <p className="text-white text-sm font-medium">Daily Bonus</p>
        </button>
        <button 
          onClick={() => setCurrentPage('purchase')}
          className="bg-[#1a2c38] hover:bg-[#243b4d] rounded-xl p-4 border border-[#2f4553] transition-colors text-center"
        >
          <ShoppingCart className="w-6 h-6 text-[#fbbf24] mx-auto mb-2" />
          <p className="text-white text-sm font-medium">Buy Coins</p>
        </button>
        <button 
          onClick={() => setCurrentPage('withdrawal')}
          className="bg-[#1a2c38] hover:bg-[#243b4d] rounded-xl p-4 border border-[#2f4553] transition-colors text-center"
        >
          <ArrowRightLeft className="w-6 h-6 text-[#00e701] mx-auto mb-2" />
          <p className="text-white text-sm font-medium">Withdraw</p>
        </button>
      </div>

      {/* Recent Transactions */}
      <div className="bg-[#1a2c38] rounded-xl border border-[#2f4553] overflow-hidden">
        <div className="p-4 border-b border-[#2f4553] flex items-center gap-2">
          <History className="w-5 h-5 text-[#557086]" />
          <h2 className="text-white font-bold">Recent Transactions</h2>
        </div>
        {recentTransactions.length === 0 ? (
          <div className="p-8 text-center text-[#557086]">
            No transactions yet
          </div>
        ) : (
          <div className="divide-y divide-[#2f4553]">
            {recentTransactions.map((tx) => (
              <div key={tx.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-white text-sm">{tx.description}</p>
                  <p className="text-[#557086] text-xs">
                    {new Date(tx.timestamp).toLocaleDateString()}
                  </p>
                </div>
                <div className={cn(
                  "font-mono font-bold",
                  tx.type === 'game_win' || tx.type === 'bonus' ? 'text-[#00e701]' :
                  tx.type === 'game_loss' ? 'text-[#ff4d4d]' :
                  'text-white'
                )}>
                  {tx.type === 'game_loss' ? '-' : '+'}{tx.amount.toFixed(2)}
                  <span className={cn(
                    "text-xs ml-1",
                    tx.currency === 'gold' ? 'text-[#fbbf24]' : 'text-[#00e701]'
                  )}>
                    {tx.currency === 'gold' ? 'GC' : 'BC'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
