// Card Types
export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type Rank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  suit: Suit;
  rank: Rank;
  value: number;
  faceUp: boolean;
}

// Roulette Types
export type RouletteNumber = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
  13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 
  25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35 | 36;

export const ROULETTE_RED_NUMBERS: RouletteNumber[] = [
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36
];

// Plinko Types
export type PlinkoRisk = 'low' | 'medium' | 'high';

// Stake.us Plinko multipliers (with 1% house edge)
export const PLINKO_MULTIPLIERS: Record<PlinkoRisk, number[][]> = {
  low: [
    // 8 rows
    [1.5, 1.2, 1.1, 1, 0.5, 1, 1.1, 1.2, 1.5],
    // 9 rows
    [1.6, 1.3, 1.1, 1, 0.7, 1, 1.1, 1.3, 1.6],
    // 10+ rows
    [1.7, 1.4, 1.2, 1, 0.8, 1, 1.2, 1.4, 1.7],
  ],
  medium: [
    // 8 rows
    [2.5, 1.5, 1.1, 0.3, 0.2, 0.3, 1.1, 1.5, 2.5],
    // 9 rows
    [3, 1.7, 1.2, 0.4, 0.2, 0.4, 1.2, 1.7, 3],
    // 10+ rows
    [3.5, 2, 1.3, 0.5, 0.2, 0.5, 1.3, 2, 3.5],
  ],
  high: [
    // 8 rows
    [5, 2, 0.5, 0.2, 0, 0.2, 0.5, 2, 5],
    // 9 rows
    [6, 2.5, 0.6, 0.2, 0, 0.2, 0.6, 2.5, 6],
    // 10+ rows
    [7, 3, 0.7, 0.2, 0, 0.2, 0.7, 3, 7],
  ],
};

// Game Types
export type GameType = 
  | 'blackjack' 
  | 'roulette' 
  | 'hilo' 
  | 'limbo' 
  | 'crash' 
  | 'plinko' 
  | 'mines';

// Page Types
export type PageType = 
  | 'casino'
  | 'dailybonus'
  | 'wallet'
  | 'purchase'
  | 'withdrawal'
  | 'terms'
  | 'privacy'
  | 'support'
  | 'favourites'
  | 'recent'
  | 'new-releases'
  | 'slots'
  | 'live-dealers'
  | 'table-games';
