import type { ReactNode } from 'react';
import { useGameStore } from '@/store/GameStore';
import { cn } from '@/lib/utils';

interface GameControlsProps {
  children?: ReactNode;
  onPlay: (amount: number) => void;
  isPlaying: boolean;
  canPlay: boolean;
  playButtonText?: string;
  className?: string;
}

export const GameControls = ({
  children,
  onPlay,
  isPlaying,
  canPlay,
  playButtonText = 'Play',
  className,
}: GameControlsProps) => {
  const { selectedCurrency, balance } = useGameStore();

  const currentBalance = selectedCurrency === 'gold' ? balance.gold : balance.blackout;
  const currencySymbol = selectedCurrency === 'gold' ? '' : '$';

  return (
    <div className={cn("w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4 flex flex-col", className)}>
      {/* Balance Display */}
      <div className="mb-4 p-3 bg-[#0f1923] rounded-lg">
        <p className="text-[#557086] text-xs mb-1">Balance</p>
        <p className="text-white font-mono text-lg">
          {currencySymbol}{currentBalance.toLocaleString()}
        </p>
      </div>

      {/* Play Button */}
      {canPlay && (
        <button
          onClick={() => onPlay(10)}
          disabled={isPlaying}
          className={cn(
            "w-full py-3 rounded-lg font-bold transition-all",
            isPlaying
              ? "bg-[#00e701]/50 cursor-not-allowed"
              : "bg-[#00e701] hover:bg-[#00c701] text-black"
          )}
        >
          {isPlaying ? 'Playing...' : playButtonText}
        </button>
      )}

      {/* Custom Controls */}
      {children}
    </div>
  );
};
