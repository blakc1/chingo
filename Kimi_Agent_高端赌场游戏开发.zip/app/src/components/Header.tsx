import { useState, useEffect, useRef } from 'react';
import { Bell, User, ChevronDown, Coins, DollarSign, Wallet, Gift, Search } from 'lucide-react';
import { useGameStore, type CurrencyType } from '@/store/GameStore';
// cn utility imported but not used in this component

interface HeaderProps {
  currentGame: string;
}

export const Header = (_props: HeaderProps) => {
  const { balance, selectedCurrency, setSelectedCurrency, dailyBonus, setCurrentPage } = useGameStore();
  const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const searchRef = useRef<HTMLDivElement>(null);

  const gameTitles: Record<string, string> = {
    blackjack: 'Blackjack',
    roulette: 'Roulette',
    hilo: 'HiLo',
    limbo: 'Limbo',
    crash: 'Crash',
    plinko: 'Plinko',
    mines: 'Mines',
  };

  const handleCurrencySelect = (currency: CurrencyType) => {
    setSelectedCurrency(currency);
    setShowCurrencyDropdown(false);
  };

  // Close search when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearch(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="h-14 bg-[#0f1923] border-b border-[#1e2c38] flex items-center justify-between px-4 lg:px-6 fixed top-0 left-0 right-0 z-50">
      {/* Left - Logo (mobile only) */}
      <div className="lg:hidden flex items-center">
        <button onClick={() => setCurrentPage('casino')} className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-[#00e701] to-[#00c701] rounded-lg flex items-center justify-center">
            <span className="text-black font-bold text-sm">B</span>
          </div>
        </button>
      </div>

      {/* Center - Balance Display */}
      <div className="absolute left-1/2 -translate-x-1/2 flex items-center">
        <div className="relative">
          <button
            onClick={() => setShowCurrencyDropdown(!showCurrencyDropdown)}
            className="flex items-center gap-3 bg-[#1a2c38] hover:bg-[#243b4d] border border-[#2f4553] hover:border-[#3f5563] rounded-full px-4 py-1.5 transition-all"
          >
            {/* Gold Coins */}
            <div className="flex items-center gap-1.5">
              <div className="w-5 h-5 bg-[#fbbf24] rounded-full flex items-center justify-center">
                <Coins className="w-3 h-3 text-black" />
              </div>
              <span className="text-[#fbbf24] font-mono font-semibold text-sm">
                {balance.gold.toLocaleString()}
              </span>
            </div>
            
            {/* Divider */}
            <div className="w-px h-4 bg-[#2f4553]" />
            
            {/* BlackoutCash */}
            <div className="flex items-center gap-1.5">
              <div className="w-5 h-5 bg-[#00e701] rounded-full flex items-center justify-center">
                <DollarSign className="w-3 h-3 text-black" />
              </div>
              <span className="text-[#00e701] font-mono font-semibold text-sm">
                ${balance.blackout.toFixed(2)}
              </span>
            </div>
            
            <ChevronDown className={`w-4 h-4 text-[#557086] transition-transform ${showCurrencyDropdown ? 'rotate-180' : ''}`} />
          </button>

          {/* Currency Dropdown */}
          {showCurrencyDropdown && (
            <>
              <div 
                className="fixed inset-0 z-40"
                onClick={() => setShowCurrencyDropdown(false)}
              />
              <div className="absolute left-1/2 -translate-x-1/2 top-full mt-2 w-72 bg-[#1a2c38] border border-[#2f4553] rounded-xl shadow-2xl z-50 overflow-hidden">
                {/* Selected Currency Display */}
                <div className="p-4 border-b border-[#2f4553]">
                  <p className="text-[#557086] text-xs mb-2">Selected Currency</p>
                  {selectedCurrency === 'gold' ? (
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#fbbf24] rounded-lg flex items-center justify-center">
                        <Coins className="w-5 h-5 text-black" />
                      </div>
                      <div>
                        <p className="text-white font-semibold">Gold Coins</p>
                        <p className="text-[#fbbf24] font-mono">{balance.gold.toLocaleString()}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#00e701] rounded-lg flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-black" />
                      </div>
                      <div>
                        <p className="text-white font-semibold">BlackoutCash</p>
                        <p className="text-[#00e701] font-mono">${balance.blackout.toFixed(2)}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Switch Options */}
                <div className="p-2">
                  <button
                    onClick={() => handleCurrencySelect('gold')}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg hover:bg-[#243b4d] transition-colors ${selectedCurrency === 'gold' ? 'bg-[#243b4d]' : ''}`}
                  >
                    <div className="w-8 h-8 bg-[#fbbf24] rounded-lg flex items-center justify-center">
                      <Coins className="w-4 h-4 text-black" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-white text-sm">Gold Coins</p>
                      <p className="text-[#fbbf24] text-xs font-mono">{balance.gold.toLocaleString()}</p>
                    </div>
                    {selectedCurrency === 'gold' && (
                      <div className="w-4 h-4 bg-[#00e701] rounded-full flex items-center justify-center">
                        <span className="text-black text-xs">✓</span>
                      </div>
                    )}
                  </button>
                  
                  <button
                    onClick={() => handleCurrencySelect('blackout')}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg hover:bg-[#243b4d] transition-colors mt-1 ${selectedCurrency === 'blackout' ? 'bg-[#243b4d]' : ''}`}
                  >
                    <div className="w-8 h-8 bg-[#00e701] rounded-lg flex items-center justify-center">
                      <DollarSign className="w-4 h-4 text-black" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-white text-sm">BlackoutCash</p>
                      <p className="text-[#00e701] text-xs font-mono">${balance.blackout.toFixed(2)}</p>
                    </div>
                    {selectedCurrency === 'blackout' && (
                      <div className="w-4 h-4 bg-[#00e701] rounded-full flex items-center justify-center">
                        <span className="text-black text-xs">✓</span>
                      </div>
                    )}
                  </button>
                </div>

                {/* Quick Actions */}
                <div className="p-2 border-t border-[#2f4553]">
                  <button
                    onClick={() => {
                      setShowCurrencyDropdown(false);
                      setCurrentPage('purchase');
                    }}
                    className="w-full flex items-center gap-2 p-2 text-[#b1bad3] hover:text-white hover:bg-[#243b4d] rounded-lg transition-colors text-left text-sm"
                  >
                    <Wallet className="w-4 h-4" />
                    <span>Buy Gold Coins</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowCurrencyDropdown(false);
                      setCurrentPage('dailybonus');
                    }}
                    className="w-full flex items-center gap-2 p-2 text-[#b1bad3] hover:text-white hover:bg-[#243b4d] rounded-lg transition-colors text-left text-sm mt-1"
                  >
                    <Gift className="w-4 h-4" />
                    <span>Daily Bonus</span>
                    {dailyBonus.canClaim && (
                      <span className="ml-auto bg-[#00e701] text-black text-[10px] px-1.5 py-0.5 rounded font-bold">NEW</span>
                    )}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Right - Actions */}
      <div className="flex items-center gap-1">
        {/* Wallet Button */}
        <button
          onClick={() => setCurrentPage('wallet')}
          className="p-2 text-[#b1bad3] hover:text-white hover:bg-[#1a2c38] rounded-lg transition-colors"
        >
          <Wallet className="w-5 h-5" />
        </button>

        {/* Search Icon */}
        <div ref={searchRef} className="relative">
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="p-2 text-[#b1bad3] hover:text-white hover:bg-[#1a2c38] rounded-lg transition-colors"
          >
            <Search className="w-5 h-5" />
          </button>
          
          {/* Search Dropdown */}
          {showSearch && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-[#1a2c38] border border-[#2f4553] rounded-xl shadow-2xl z-50 overflow-hidden p-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#557086]" />
                <input
                  type="text"
                  placeholder="Search games..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-[#0f1923] border border-[#2f4553] rounded-lg text-white text-sm placeholder-[#557086] focus:outline-none focus:border-[#00e701] transition-colors"
                  autoFocus
                />
              </div>
              {searchQuery && (
                <div className="mt-2 space-y-1">
                  {Object.entries(gameTitles)
                    .filter(([_, title]) => title.toLowerCase().includes(searchQuery.toLowerCase()))
                    .map(([id, title]) => (
                      <button
                        key={id}
                        onClick={() => {
                          setCurrentPage('casino');
                          setShowSearch(false);
                          setSearchQuery('');
                        }}
                        className="w-full text-left p-2 hover:bg-[#243b4d] rounded-lg text-white text-sm transition-colors"
                      >
                        {title}
                      </button>
                    ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Notifications */}
        <button 
          onClick={() => setCurrentPage('dailybonus')}
          className="p-2 text-[#b1bad3] hover:text-white hover:bg-[#1a2c38] rounded-lg transition-colors relative"
        >
          <Bell className="w-5 h-5" />
          {dailyBonus.canClaim && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#00e701] rounded-full" />
          )}
        </button>

        {/* User Profile */}
        <button 
          onClick={() => setCurrentPage('support')}
          className="p-2 text-[#b1bad3] hover:text-white hover:bg-[#1a2c38] rounded-lg transition-colors"
        >
          <User className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
