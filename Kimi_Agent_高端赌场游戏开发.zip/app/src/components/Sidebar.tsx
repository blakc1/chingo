import { useState } from 'react';
import { cn } from '@/lib/utils';
import {
  Star,
  Clock,
  Gamepad2,
  Sparkles,
  Dice5,
  Flame,
  Users,
  Zap,
  Gift,
  Table2,
  LayoutGrid,
  ChevronDown,
  Menu,
  X,
  ChevronRight,
  Scale,
  Shield,
  Headphones,
  Home,
} from 'lucide-react';
import { useGameStore } from '@/store/GameStore';

interface SidebarProps {
  currentGame: string;
  onGameSelect: (game: string) => void;
}

export const Sidebar = ({ currentGame, onGameSelect }: SidebarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(['Originals']);
  const { dailyBonus, setCurrentPage } = useGameStore();

  const toggleSection = (title: string) => {
    setExpandedSections(prev =>
      prev.includes(title)
        ? prev.filter(t => t !== title)
        : [...prev, title]
    );
  };

  const originalGames = [
    { id: 'blackjack', label: 'Blackjack', icon: Table2 },
    { id: 'roulette', label: 'Roulette', icon: Dice5 },
    { id: 'hilo', label: 'HiLo', icon: Gamepad2 },
    { id: 'limbo', label: 'Limbo', icon: Zap },
    { id: 'crash', label: 'Crash', icon: Flame },
    { id: 'plinko', label: 'Plinko', icon: LayoutGrid },
    { id: 'mines', label: 'Mines', icon: Sparkles },
  ];

  const handleGameSelect = (gameId: string) => {
    onGameSelect(gameId);
    setCurrentPage('casino');
    setIsOpen(false);
  };

  const handleNavClick = (page: string) => {
    setCurrentPage(page);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="lg:hidden fixed top-3 left-4 z-50 p-2 bg-[#1a2c38] rounded-lg text-white hover:bg-[#243b4d] transition-colors"
      >
        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed left-0 top-14 h-[calc(100vh-3.5rem)] w-60 bg-[#0f1923] border-r border-[#1e2c38] z-40 overflow-y-auto',
          'transform transition-transform duration-300 ease-in-out',
          'lg:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Navigation */}
        <nav className="p-2">
          {/* Main Menu */}
          <div className="space-y-0.5 mb-2">
            <button
              onClick={() => handleNavClick('casino')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
            >
              <Home className="w-4 h-4" />
              <span>Casino</span>
            </button>
            <button
              onClick={() => handleNavClick('favourites')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
            >
              <Star className="w-4 h-4" />
              <span>Favourites</span>
            </button>
            <button
              onClick={() => handleNavClick('recent')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
            >
              <Clock className="w-4 h-4" />
              <span>Recent</span>
            </button>
          </div>

          {/* Daily Bonus */}
          <div className="mb-2">
            <button
              onClick={() => handleNavClick('dailybonus')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors bg-gradient-to-r from-[#00e701]/10 to-transparent text-[#00e701] hover:bg-[#00e701]/10"
            >
              <Gift className="w-4 h-4" />
              <span>Daily Bonus</span>
              {dailyBonus.canClaim && (
                <span className="ml-auto bg-[#00e701] text-black text-[10px] px-1.5 py-0.5 rounded font-bold">
                  CLAIM
                </span>
              )}
            </button>
          </div>

          {/* Originals Section */}
          <div className="mb-2">
            <button
              onClick={() => toggleSection('Originals')}
              className="w-full flex items-center justify-between px-3 py-2 text-[#557086] text-xs font-semibold uppercase tracking-wider hover:text-[#b1bad3] transition-colors"
            >
              <span>Blackout Originals</span>
              <ChevronDown
                className={cn(
                  'w-3 h-3 transition-transform',
                  expandedSections.includes('Originals') && 'rotate-180'
                )}
              />
            </button>

            {expandedSections.includes('Originals') && (
              <div className="space-y-0.5 mt-1">
                {originalGames.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleGameSelect(item.id)}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                      currentGame === item.id
                        ? 'bg-[#00e701]/10 text-[#00e701]'
                        : 'text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]'
                    )}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                    {currentGame === item.id && (
                      <ChevronRight className="w-3 h-3 ml-auto" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Categories */}
          <div className="mb-2">
            <button
              onClick={() => toggleSection('Categories')}
              className="w-full flex items-center justify-between px-3 py-2 text-[#557086] text-xs font-semibold uppercase tracking-wider hover:text-[#b1bad3] transition-colors"
            >
              <span>Categories</span>
              <ChevronDown
                className={cn(
                  'w-3 h-3 transition-transform',
                  expandedSections.includes('Categories') && 'rotate-180'
                )}
              />
            </button>

            {expandedSections.includes('Categories') && (
              <div className="space-y-0.5 mt-1">
                <button
                  onClick={() => handleNavClick('new-releases')}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
                >
                  <Zap className="w-4 h-4" />
                  <span>New Releases</span>
                </button>
                <button
                  onClick={() => handleNavClick('slots')}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
                >
                  <Dice5 className="w-4 h-4" />
                  <span>Slots</span>
                </button>
                <button
                  onClick={() => handleNavClick('live-dealers')}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
                >
                  <Users className="w-4 h-4" />
                  <span>Live Dealers</span>
                </button>
                <button
                  onClick={() => handleNavClick('table-games')}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-[#b1bad3] hover:text-white hover:bg-[#1a2c38]"
                >
                  <Table2 className="w-4 h-4" />
                  <span>Table Games</span>
                </button>
              </div>
            )}
          </div>

          {/* Legal Links */}
          <div className="pt-2 border-t border-[#1e2c38]">
            <button
              onClick={() => handleNavClick('terms')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors text-[#557086] hover:text-[#b1bad3] hover:bg-[#1a2c38]"
            >
              <Scale className="w-3 h-3" />
              <span>Terms</span>
            </button>
            <button
              onClick={() => handleNavClick('privacy')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors text-[#557086] hover:text-[#b1bad3] hover:bg-[#1a2c38]"
            >
              <Shield className="w-3 h-3" />
              <span>Privacy</span>
            </button>
            <button
              onClick={() => handleNavClick('support')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors text-[#557086] hover:text-[#b1bad3] hover:bg-[#1a2c38]"
            >
              <Headphones className="w-3 h-3" />
              <span>Support</span>
            </button>
          </div>
        </nav>
      </aside>

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
};
