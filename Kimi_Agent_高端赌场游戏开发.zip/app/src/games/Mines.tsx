import { useState } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { Shield, Check, X, Bomb, Gem } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

// Mines game with 1% house edge
// Grid of tiles, some contain mines
// Player reveals tiles, cashing out before hitting a mine

const GRID_SIZE = 5; // 5x5 grid
const TOTAL_TILES = GRID_SIZE * GRID_SIZE;

// Payout multipliers based on mines count and tiles revealed
// These are calculated to give approximately 1% house edge
const PAYOUT_TABLE: Record<number, number[]> = {
  1: [1.03, 1.06, 1.09, 1.13, 1.17, 1.22, 1.27, 1.33, 1.40, 1.48, 1.57, 1.68, 1.81, 1.97, 2.17, 2.43, 2.78, 3.29, 4.09, 5.44, 8.16, 16.33, 49.00, 196.00],
  3: [1.12, 1.26, 1.43, 1.63, 1.87, 2.17, 2.55, 3.04, 3.69, 4.59, 5.87, 7.78, 10.82, 16.23, 27.05, 54.11, 135.28, 541.13],
  5: [1.24, 1.49, 1.82, 2.26, 2.87, 3.74, 5.03, 7.04, 10.34, 16.28, 27.84, 53.20, 117.04, 304.31, 1014.38, 4564.71],
  10: [1.71, 2.48, 3.78, 6.09, 10.55, 19.87, 41.39, 97.39, 263.00, 876.67, 3945.00, 39450.00],
  15: [2.63, 4.74, 9.48, 21.33, 53.33, 152.38, 507.94, 2031.75, 12190.50, 182857.50],
  20: [5.44, 16.33, 65.33, 391.99, 3919.90, 117597.00],
};

interface Tile {
  index: number;
  isMine: boolean;
  isRevealed: boolean;
}

export const Mines = () => {
  const { subtractFromBalance, addToBalance, addGameHistory, selectedCurrency, provablyFair, createGameVerification, getNextNonce } = useGameStore();
  const { playSound, playWinSound, playLoseSound, playCashoutSound } = useSound();
  
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'finished'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [mineCount, setMineCount] = useState(3);
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [revealedCount, setRevealedCount] = useState(0);
  const [currentMultiplier, setCurrentMultiplier] = useState(1);
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);
  const [history, setHistory] = useState<{ mines: number; revealed: number; win: boolean }[]>([]);
  const [hitMine, setHitMine] = useState<number | null>(null);

  const getPayoutMultiplier = (mines: number, revealed: number): number => {
    const payouts = PAYOUT_TABLE[mines];
    if (!payouts || revealed <= 0) return 1;
    return payouts[Math.min(revealed - 1, payouts.length - 1)] || payouts[payouts.length - 1];
  };

  const initializeGame = () => {
    if (!subtractFromBalance(betAmount, selectedCurrency)) return;

    playSound('click');
    
    // Generate mine positions using provably fair
    const nonce = getNextNonce();
    const minePositions = new Set<number>();
    
    while (minePositions.size < mineCount) {
      const random = generateRandomFromSeed(
        provablyFair.serverSeed, 
        provablyFair.clientSeed, 
        nonce + minePositions.size
      );
      const position = Math.floor(random * TOTAL_TILES);
      minePositions.add(position);
    }

    const newTiles: Tile[] = [];
    for (let i = 0; i < TOTAL_TILES; i++) {
      newTiles.push({
        index: i,
        isMine: minePositions.has(i),
        isRevealed: false,
      });
    }

    setTiles(newTiles);
    setRevealedCount(0);
    setCurrentMultiplier(1);
    setGameState('playing');
    setShowVerification(false);
    setCurrentVerification(null);
    setHitMine(null);
  };

  const revealTile = (index: number) => {
    if (gameState !== 'playing') return;
    
    const tile = tiles[index];
    if (tile.isRevealed) return;

    const newTiles = [...tiles];
    newTiles[index].isRevealed = true;
    setTiles(newTiles);

    if (tile.isMine) {
      // Hit a mine - game over
      playLoseSound();
      setHitMine(index);
      setGameState('finished');
      
      // Reveal all mines
      const allTiles = newTiles.map(t => ({ ...t, isRevealed: t.isRevealed || t.isMine }));
      setTiles(allTiles);

      // Update history
      setHistory(prev => [{ mines: mineCount, revealed: revealedCount, win: false }, ...prev].slice(0, 20));

      const gameData = {
        mineCount,
        revealedCount,
        hitTile: index,
        minePositions: newTiles.filter(t => t.isMine).map(t => t.index),
      };

      const verification = createGameVerification(
        'Mines',
        betAmount,
        selectedCurrency,
        'loss',
        0,
        gameData
      );
      setCurrentVerification(verification);

      addGameHistory({
        game: 'Mines',
        bet: betAmount,
        currency: selectedCurrency,
        result: 'loss',
        amount: 0,
        gameId: verification.gameId,
      });
    } else {
      // Safe tile
      playWinSound();
      const newRevealedCount = revealedCount + 1;
      setRevealedCount(newRevealedCount);
      const newMultiplier = getPayoutMultiplier(mineCount, newRevealedCount);
      setCurrentMultiplier(newMultiplier);

      // Check if all safe tiles revealed (win condition)
      const safeTiles = TOTAL_TILES - mineCount;
      if (newRevealedCount >= safeTiles) {
        handleCashout(newMultiplier);
      }
    }
  };

  const handleCashout = (multiplier?: number) => {
    if (gameState !== 'playing' || revealedCount === 0) return;

    playCashoutSound();
    const cashoutMultiplier = multiplier || currentMultiplier;
    const winAmount = betAmount * cashoutMultiplier;
    const profit = winAmount - betAmount;
    
    addToBalance(winAmount, selectedCurrency);
    setGameState('finished');

    // Update history
    setHistory(prev => [{ mines: mineCount, revealed: revealedCount, win: true }, ...prev].slice(0, 20));

    const gameData = {
      mineCount,
      revealedCount,
      cashoutMultiplier,
      minePositions: tiles.filter(t => t.isMine).map(t => t.index),
    };

    const verification = createGameVerification(
      'Mines',
      betAmount,
      selectedCurrency,
      'win',
      profit,
      gameData
    );
    setCurrentVerification(verification);

    addGameHistory({
      game: 'Mines',
      bet: betAmount,
      currency: selectedCurrency,
      result: 'win',
      amount: profit,
      multiplier: cashoutMultiplier,
      gameId: verification.gameId,
    });
  };

  const handlePlayAgain = () => {
    setGameState('idle');
    setTiles([]);
    setRevealedCount(0);
    setCurrentMultiplier(1);
    setShowVerification(false);
    setHitMine(null);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full">
      {/* Controls */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4">
        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Bet Amount</label>
          <input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
            disabled={gameState === 'playing'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
        </div>

        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Mines</label>
          <input
            type="number"
            min="1"
            max="24"
            value={mineCount}
            onChange={(e) => setMineCount(Math.max(1, Math.min(24, parseInt(e.target.value) || 1)))}
            disabled={gameState === 'playing'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
        </div>

        {gameState === 'idle' && (
          <button 
            onClick={initializeGame} 
            className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-colors"
          >
            Start Game
          </button>
        )}

        {gameState === 'playing' && (
          <>
            <button 
              onClick={() => handleCashout()}
              disabled={revealedCount === 0}
              className={cn(
                'w-full py-3 font-bold rounded-lg transition-all mb-3',
                revealedCount === 0
                  ? 'bg-[#2f4553] text-white cursor-not-allowed'
                  : 'bg-[#00e701] hover:bg-[#00c701] text-black animate-pulse'
              )}
            >
              Cashout {currentMultiplier.toFixed(2)}x
            </button>
            <div className="p-3 bg-[#0f1923] rounded-lg">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-[#b1bad3]">Revealed</span>
                <span className="text-white font-bold">{revealedCount}/{TOTAL_TILES - mineCount}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#b1bad3]">Next Multiplier</span>
                <span className="text-[#00e701] font-bold">
                  {getPayoutMultiplier(mineCount, revealedCount + 1).toFixed(2)}x
                </span>
              </div>
            </div>
          </>
        )}

        {gameState === 'finished' && (
          <>
            <button 
              onClick={handlePlayAgain} 
              className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg mb-3 transition-colors"
            >
              Play Again
            </button>
            {currentVerification && (
              <button 
                onClick={() => setShowVerification(!showVerification)} 
                className="w-full py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm hover:bg-[#00e701]/10 rounded-lg transition-colors"
              >
                <Shield className="w-4 h-4" />
                Verify Fairness
              </button>
            )}
          </>
        )}

        {/* History */}
        <div className="mt-4">
          <p className="text-[#557086] text-xs mb-2">History</p>
          <div className="flex flex-wrap gap-1">
            {history.slice(0, 10).map((h, i) => (
              <div 
                key={i} 
                className={cn(
                  'w-8 h-6 rounded text-xs font-mono flex items-center justify-center',
                  h.win ? 'bg-[#00e701]/20 text-[#00e701]' : 'bg-[#ff4d4d]/20 text-[#ff4d4d]'
                )}
              >
                {h.revealed}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Area */}
      <div className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 flex flex-col items-center justify-center relative overflow-hidden">
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3 mb-4">
                <div className="flex items-center gap-2 text-[#00e701]">
                  <Check className="w-5 h-5" />
                  <span className="font-semibold">Verified</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Grid */}
        <div className="grid grid-cols-5 gap-2 p-4">
          {gameState === 'idle' ? (
            // Empty grid before game starts
            Array.from({ length: TOTAL_TILES }).map((_, i) => (
              <button
                key={i}
                disabled
                className="w-14 h-14 sm:w-16 sm:h-16 bg-[#1a2c38] rounded-lg border border-[#2f4553] cursor-not-allowed"
              />
            ))
          ) : (
            // Active game grid
            tiles.map((tile) => (
              <button
                key={tile.index}
                onClick={() => revealTile(tile.index)}
                disabled={tile.isRevealed || gameState !== 'playing'}
                className={cn(
                  'w-14 h-14 sm:w-16 sm:h-16 rounded-lg border transition-all duration-200 flex items-center justify-center',
                  tile.isRevealed
                    ? tile.isMine
                      ? hitMine === tile.index
                        ? 'bg-[#ff4d4d] border-[#ff4d4d] animate-pulse'
                        : 'bg-[#ff4d4d]/50 border-[#ff4d4d]/50'
                      : 'bg-[#00e701]/20 border-[#00e701]/50'
                    : 'bg-[#1a2c38] border-[#2f4553] hover:bg-[#243b4d] hover:border-[#3b82f6]',
                  gameState !== 'playing' && !tile.isRevealed && 'cursor-not-allowed opacity-70'
                )}
              >
                {tile.isRevealed && (
                  tile.isMine ? (
                    <Bomb className="w-6 h-6 text-white" />
                  ) : (
                    <Gem className="w-6 h-6 text-[#00e701]" />
                  )
                )}
              </button>
            ))
          )}
        </div>

        {/* Result message */}
        {gameState === 'finished' && hitMine !== null && (
          <div className="mt-4 text-2xl font-bold text-[#ff4d4d]">
            BOOM! You hit a mine!
          </div>
        )}

        {gameState === 'finished' && hitMine === null && revealedCount > 0 && (
          <div className="mt-4 text-2xl font-bold text-[#00e701]">
            +{(betAmount * currentMultiplier - betAmount).toFixed(2)}
          </div>
        )}

        {/* Fairness indicator */}
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
