import { useState, useRef, useEffect, useCallback } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { Shield, Check, X, Zap } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

// Crash game with 1% house edge
// Uses exponential distribution with house edge adjustment
// crashPoint = 0.99 / (1 - random) when random < 0.99, otherwise instant crash

const calculateCrashPoint = (random: number): number => {
  // 1% chance of instant crash at 1.00
  if (random >= 0.99) return 1.00;
  
  // House edge: 1% (0.99 multiplier)
  // Formula gives exponential distribution
  const result = 0.99 / (1 - random);
  return Math.max(1.00, Math.floor(result * 100) / 100);
};

export const Crash = () => {
  const { subtractFromBalance, addToBalance, addGameHistory, selectedCurrency, provablyFair, createGameVerification, getNextNonce } = useGameStore();
  const { playSound, playWinSound, playCrashSound } = useSound();
  
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'crashed'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [autoCashout, setAutoCashout] = useState(2.00);
  const [currentMultiplier, setCurrentMultiplier] = useState(1.00);
  const [crashPoint, setCrashPoint] = useState<number | null>(null);
  const [hasCashedOut, setHasCashedOut] = useState(false);
  const [cashoutMultiplier, setCashoutMultiplier] = useState<number | null>(null);
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);
  const [history, setHistory] = useState<{ crashPoint: number }[]>([]);
  
  const animationRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);

  const startGame = () => {
    if (!subtractFromBalance(betAmount, selectedCurrency)) return;

    playSound('click');
    setGameState('playing');
    setCurrentMultiplier(1.00);
    setHasCashedOut(false);
    setCashoutMultiplier(null);
    setShowVerification(false);
    setCurrentVerification(null);

    const nonce = getNextNonce();
    const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, nonce);
    const targetCrash = calculateCrashPoint(random);
    setCrashPoint(targetCrash);

    startTimeRef.current = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTimeRef.current;
      // Exponential growth curve
      const growthRate = 0.0005; // Adjust for speed
      const multiplier = Math.exp(elapsed * growthRate);
      const roundedMultiplier = Math.floor(multiplier * 100) / 100;
      
      setCurrentMultiplier(roundedMultiplier);

      // Check auto cashout
      if (!hasCashedOut && autoCashout > 1 && roundedMultiplier >= autoCashout) {
        handleCashout(roundedMultiplier);
        return;
      }

      // Check crash
      if (roundedMultiplier >= targetCrash) {
        setGameState('crashed');
        playCrashSound();
        setHistory(prev => [{ crashPoint: targetCrash }, ...prev].slice(0, 20));
        
        if (!hasCashedOut) {
          // Player lost
          const gameData = {
            crashPoint: targetCrash,
            cashoutAt: null,
            random,
            nonce,
          };

          const verification = createGameVerification(
            'Crash',
            betAmount,
            selectedCurrency,
            'loss',
            0,
            gameData
          );
          setCurrentVerification(verification);

          addGameHistory({
            game: 'Crash',
            bet: betAmount,
            currency: selectedCurrency,
            result: 'loss',
            amount: 0,
            gameId: verification.gameId,
          });
        }
        return;
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
  };

  const handleCashout = useCallback((atMultiplier?: number) => {
    if (hasCashedOut || gameState !== 'playing' || !crashPoint) return;

    const cashoutAt = atMultiplier || currentMultiplier;
    
    if (cashoutAt >= crashPoint) return; // Can't cashout at or after crash

    setHasCashedOut(true);
    setCashoutMultiplier(cashoutAt);
    
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }

    playWinSound();
    const winAmount = betAmount * cashoutAt;
    const profit = winAmount - betAmount;
    addToBalance(winAmount, selectedCurrency);

    const nonce = getNextNonce() - 1; // Use the same nonce as the game
    const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, nonce);

    const gameData = {
      crashPoint,
      cashoutAt,
      random,
      nonce,
    };

    const verification = createGameVerification(
      'Crash',
      betAmount,
      selectedCurrency,
      'win',
      profit,
      gameData
    );
    setCurrentVerification(verification);

    addGameHistory({
      game: 'Crash',
      bet: betAmount,
      currency: selectedCurrency,
      result: 'win',
      amount: profit,
      multiplier: cashoutAt,
      gameId: verification.gameId,
    });

    setGameState('crashed');
    setHistory(prev => [{ crashPoint }, ...prev].slice(0, 20));
  }, [hasCashedOut, gameState, crashPoint, currentMultiplier, betAmount, provablyFair, getNextNonce, createGameVerification, addToBalance, addGameHistory, selectedCurrency, playWinSound]);

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const handlePlayAgain = () => {
    setGameState('idle');
    setCurrentMultiplier(1.00);
    setCrashPoint(null);
    setHasCashedOut(false);
    setCashoutMultiplier(null);
    setShowVerification(false);
  };

  // Generate graph points for visualization
  const generateGraphPoints = () => {
    const points = [];
    const maxPoints = 50;
    for (let i = 0; i <= maxPoints; i++) {
      const t = i / maxPoints;
      const elapsed = t * 10000; // 10 seconds max
      const growthRate = 0.0005;
      const multiplier = Math.exp(elapsed * growthRate);
      const x = t * 100;
      const y = 100 - (Math.min(multiplier, 10) / 10) * 80;
      points.push(`${x},${y}`);
    }
    return points.join(' ');
  };

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full">
      {/* Controls */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4">
        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Bet Amount</label>
          <input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
            disabled={gameState === 'playing'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
        </div>

        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Auto Cashout</label>
          <input
            type="number"
            step="0.01"
            min="1.01"
            value={autoCashout}
            onChange={(e) => setAutoCashout(parseFloat(e.target.value) || 1.01)}
            disabled={gameState === 'playing'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
          <p className="text-[#557086] text-xs mt-1">Set to 0 to disable</p>
        </div>

        {gameState === 'idle' && (
          <button 
            onClick={startGame} 
            className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-colors"
          >
            Start Game
          </button>
        )}

        {gameState === 'playing' && (
          <button 
            onClick={() => handleCashout()}
            disabled={hasCashedOut}
            className={cn(
              'w-full py-3 font-bold rounded-lg transition-all',
              hasCashedOut 
                ? 'bg-[#2f4553] text-white cursor-not-allowed' 
                : 'bg-[#00e701] hover:bg-[#00c701] text-black animate-pulse'
            )}
          >
            {hasCashedOut ? 'Cashed Out' : `Cashout @ ${currentMultiplier.toFixed(2)}x`}
          </button>
        )}

        {gameState === 'crashed' && (
          <>
            <button 
              onClick={handlePlayAgain} 
              className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg mb-3 transition-colors"
            >
              Play Again
            </button>
            {currentVerification && (
              <button 
                onClick={() => setShowVerification(!showVerification)} 
                className="w-full py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm hover:bg-[#00e701]/10 rounded-lg transition-colors"
              >
                <Shield className="w-4 h-4" />
                Verify Fairness
              </button>
            )}
          </>
        )}

        {/* History */}
        <div className="mt-4">
          <p className="text-[#557086] text-xs mb-2">Crash History</p>
          <div className="flex flex-wrap gap-1">
            {history.slice(0, 10).map((h, i) => (
              <div 
                key={i} 
                className={cn(
                  'w-10 h-6 rounded text-xs font-mono flex items-center justify-center',
                  h.crashPoint >= 2 ? 'bg-[#00e701]/20 text-[#00e701]' : 'bg-[#ff4d4d]/20 text-[#ff4d4d]'
                )}
              >
                {h.crashPoint.toFixed(2)}x
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Area */}
      <div className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 flex flex-col items-center justify-center relative overflow-hidden">
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3 mb-4">
                <div className="flex items-center gap-2 text-[#00e701]">
                  <Check className="w-5 h-5" />
                  <span className="font-semibold">Verified</span>
                </div>
              </div>
              <div className="space-y-3 text-sm">
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Game ID</p>
                  <p className="text-white font-mono text-xs break-all">{currentVerification.gameId}</p>
                </div>
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Server Seed Hash</p>
                  <p className="text-white font-mono text-xs break-all">{currentVerification.serverSeedHash}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Graph visualization */}
        <div className="relative w-full max-w-md aspect-video">
          {/* Grid lines */}
          <div className="absolute inset-0">
            {[1, 2, 3, 4, 5].map((i) => (
              <div 
                key={i} 
                className="absolute w-full border-t border-[#2f4553]/30"
                style={{ top: `${i * 20}%` }}
              />
            ))}
          </div>

          {/* Current multiplier display */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className={cn(
              'text-center transition-all duration-100',
              gameState === 'playing' && 'scale-110'
            )}>
              <div className={cn(
                'text-6xl font-bold font-mono transition-colors',
                gameState === 'crashed' ? 'text-[#ff4d4d]' : 'text-white',
                gameState === 'playing' && currentMultiplier >= 2 && 'text-[#00e701]'
              )}>
                {currentMultiplier.toFixed(2)}x
              </div>
              {gameState === 'playing' && !hasCashedOut && (
                <div className="flex items-center justify-center gap-1 mt-2 text-[#00e701]">
                  <Zap className="w-4 h-4" />
                  <span className="text-sm">Rising...</span>
                </div>
              )}
              {hasCashedOut && cashoutMultiplier && (
                <div className="mt-2 text-[#00e701] font-bold">
                  Cashed Out @ {cashoutMultiplier.toFixed(2)}x
                </div>
              )}
              {gameState === 'crashed' && crashPoint && !hasCashedOut && (
                <div className="mt-2 text-[#ff4d4d] font-bold">
                  Crashed @ {crashPoint.toFixed(2)}x
                </div>
              )}
            </div>
          </div>

          {/* Progress line */}
          {gameState !== 'idle' && (
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <polyline
                points={generateGraphPoints()}
                fill="none"
                stroke={gameState === 'crashed' && !hasCashedOut ? '#ff4d4d' : '#00e701'}
                strokeWidth="0.5"
                className="opacity-30"
              />
            </svg>
          )}
        </div>

        {/* Fairness indicator */}
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
