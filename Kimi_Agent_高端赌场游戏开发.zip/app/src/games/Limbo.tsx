import { useState, useRef, useEffect } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { TrendingUp, Shield, Check, X } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

// Limbo game with 1% house edge
// Uses exponential distribution: result = 0.99 / random
// This gives a 1% house edge

const calculateLimboResult = (random: number): number => {
  // House edge: 1% (multiply by 0.99)
  // Formula: 0.99 / (1 - random) gives exponential distribution
  // Cap at 1000x for sanity
  const result = Math.min(1000, 0.99 / (1 - random));
  return Math.floor(result * 100) / 100; // Round to 2 decimal places
};

export const Limbo = () => {
  const { subtractFromBalance, addToBalance, addGameHistory, selectedCurrency, provablyFair, createGameVerification, getNextNonce } = useGameStore();
  const { playSound, playWinSound, playLoseSound } = useSound();
  
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'finished'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [targetMultiplier, setTargetMultiplier] = useState(2.00);
  const [currentResult, setCurrentResult] = useState<number | null>(null);
  const [isWin, setIsWin] = useState<boolean | null>(null);
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);
  const [history, setHistory] = useState<{ result: number; win: boolean }[]>([]);
  const [animatingNumber, setAnimatingNumber] = useState<number | null>(null);
  
  const animationRef = useRef<number | null>(null);

  const playGame = () => {
    if (gameState === 'playing') return;
    if (!subtractFromBalance(betAmount, selectedCurrency)) return;

    playSound('click');
    setGameState('playing');
    setCurrentResult(null);
    setIsWin(null);
    setShowVerification(false);

    const nonce = getNextNonce();
    const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, nonce);
    const result = calculateLimboResult(random);
    const win = result >= targetMultiplier;

    // Animate the number
    let startTime: number;
    const duration = 800; // ms
    
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      // Easing function
      const easeOut = 1 - Math.pow(1 - progress, 3);
      
      if (progress < 1) {
        setAnimatingNumber(Math.floor(result * easeOut * 100) / 100);
        animationRef.current = requestAnimationFrame(animate);
      } else {
        setAnimatingNumber(null);
        setCurrentResult(result);
        setIsWin(win);
        setGameState('finished');
        
        // Update history
        setHistory(prev => [{ result, win }, ...prev].slice(0, 20));

        const gameData = {
          targetMultiplier,
          result,
          random,
          nonce,
        };

        if (win) {
          playWinSound();
          const winAmount = betAmount * targetMultiplier;
          const profit = winAmount - betAmount;
          addToBalance(winAmount, selectedCurrency);

          const verification = createGameVerification(
            'Limbo',
            betAmount,
            selectedCurrency,
            'win',
            profit,
            gameData
          );
          setCurrentVerification(verification);

          addGameHistory({
            game: 'Limbo',
            bet: betAmount,
            currency: selectedCurrency,
            result: 'win',
            amount: profit,
            multiplier: targetMultiplier,
            gameId: verification.gameId,
          });
        } else {
          playLoseSound();
          const verification = createGameVerification(
            'Limbo',
            betAmount,
            selectedCurrency,
            'loss',
            0,
            gameData
          );
          setCurrentVerification(verification);

          addGameHistory({
            game: 'Limbo',
            bet: betAmount,
            currency: selectedCurrency,
            result: 'loss',
            amount: 0,
            gameId: verification.gameId,
          });
        }
      }
    };

    animationRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const handlePlayAgain = () => {
    setGameState('idle');
    setCurrentResult(null);
    setIsWin(null);
    setShowVerification(false);
  };

  // Calculate probability of winning
  const winProbability = (0.99 / targetMultiplier * 100).toFixed(2);

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full">
      {/* Controls */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4">
        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Bet Amount</label>
          <input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
            disabled={gameState === 'playing'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
        </div>

        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Target Multiplier</label>
          <input
            type="number"
            step="0.01"
            min="1.01"
            value={targetMultiplier}
            onChange={(e) => setTargetMultiplier(parseFloat(e.target.value) || 1.01)}
            disabled={gameState === 'playing'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
          <p className="text-[#557086] text-xs mt-1">Win probability: {winProbability}%</p>
        </div>

        {gameState === 'idle' && (
          <button 
            onClick={playGame} 
            className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-colors"
          >
            Play
          </button>
        )}

        {gameState === 'playing' && (
          <button 
            disabled 
            className="w-full py-3 bg-[#2f4553] text-white font-bold rounded-lg cursor-not-allowed"
          >
            Rolling...
          </button>
        )}

        {gameState === 'finished' && (
          <>
            <button 
              onClick={handlePlayAgain} 
              className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg mb-3 transition-colors"
            >
              Play Again
            </button>
            {currentVerification && (
              <button 
                onClick={() => setShowVerification(!showVerification)} 
                className="w-full py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm hover:bg-[#00e701]/10 rounded-lg transition-colors"
              >
                <Shield className="w-4 h-4" />
                Verify Fairness
              </button>
            )}
          </>
        )}

        {/* History */}
        <div className="mt-4">
          <p className="text-[#557086] text-xs mb-2">History</p>
          <div className="flex flex-wrap gap-1">
            {history.slice(0, 10).map((h, i) => (
              <div 
                key={i} 
                className={cn(
                  'w-10 h-6 rounded text-xs font-mono flex items-center justify-center',
                  h.win ? 'bg-[#00e701]/20 text-[#00e701]' : 'bg-[#ff4d4d]/20 text-[#ff4d4d]'
                )}
              >
                {h.result.toFixed(2)}x
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Area */}
      <div className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 flex flex-col items-center justify-center relative overflow-hidden">
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3 mb-4">
                <div className="flex items-center gap-2 text-[#00e701]">
                  <Check className="w-5 h-5" />
                  <span className="font-semibold">Verified</span>
                </div>
              </div>
              <div className="space-y-3 text-sm">
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Game ID</p>
                  <p className="text-white font-mono text-xs break-all">{currentVerification.gameId}</p>
                </div>
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Server Seed Hash</p>
                  <p className="text-white font-mono text-xs break-all">{currentVerification.serverSeedHash}</p>
                </div>
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Client Seed</p>
                  <p className="text-white font-mono text-xs break-all">{currentVerification.clientSeed}</p>
                </div>
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Nonce</p>
                  <p className="text-white font-mono">{currentVerification.nonce}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Result Display */}
        <div className="relative">
          {/* Target line */}
          <div className="absolute -left-32 top-1/2 -translate-y-1/2 flex items-center gap-2">
            <div className="text-right">
              <p className="text-[#557086] text-xs">Target</p>
              <p className="text-[#3b82f6] font-bold font-mono text-xl">{targetMultiplier.toFixed(2)}x</p>
            </div>
            <div className="w-4 h-px bg-[#3b82f6]" />
          </div>

          {/* Main number display */}
          <div className={cn(
            'w-48 h-48 rounded-full border-4 flex items-center justify-center transition-all duration-300',
            gameState === 'finished' 
              ? isWin 
                ? 'border-[#00e701] bg-[#00e701]/10 shadow-[0_0_40px_rgba(0,231,1,0.3)]' 
                : 'border-[#ff4d4d] bg-[#ff4d4d]/10 shadow-[0_0_40px_rgba(255,77,77,0.3)]'
              : 'border-[#2f4553] bg-[#1a2c38]'
          )}>
            <div className="text-center">
              {animatingNumber !== null ? (
                <span className={cn(
                  'text-4xl font-bold font-mono',
                  animatingNumber >= targetMultiplier ? 'text-[#00e701]' : 'text-[#ff4d4d]'
                )}>
                  {animatingNumber.toFixed(2)}x
                </span>
              ) : currentResult !== null ? (
                <span className={cn(
                  'text-4xl font-bold font-mono',
                  isWin ? 'text-[#00e701]' : 'text-[#ff4d4d]'
                )}>
                  {currentResult.toFixed(2)}x
                </span>
              ) : (
                <TrendingUp className="w-12 h-12 text-[#557086]" />
              )}
            </div>
          </div>
        </div>

        {gameState === 'finished' && isWin !== null && (
          <div className={cn(
            'mt-6 text-2xl font-bold',
            isWin ? 'text-[#00e701]' : 'text-[#ff4d4d]'
          )}>
            {isWin ? `+${(betAmount * targetMultiplier - betAmount).toFixed(2)}` : 'BUST'}
          </div>
        )}

        {/* Fairness indicator */}
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
