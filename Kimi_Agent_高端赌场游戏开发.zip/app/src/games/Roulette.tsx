import { useState } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { ROULETTE_RED_NUMBERS, type RouletteNumber } from '@/types';
import { RotateCcw, Undo2, Shield, Check, X } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

const NUMBERS: RouletteNumber[] = [
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
  13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
  25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
];

const isRed = (num: RouletteNumber): boolean => ROULETTE_RED_NUMBERS.includes(num);

interface Bet {
  type: 'number' | 'red' | 'black' | 'even' | 'odd' | 'low' | 'high' | 'dozen1' | 'dozen2' | 'dozen3' | 'column1' | 'column2' | 'column3';
  value?: number;
  amount: number;
}

const PAYOUTS: Record<Bet['type'], number> = {
  number: 36,
  red: 2,
  black: 2,
  even: 2,
  odd: 2,
  low: 2,
  high: 2,
  dozen1: 3,
  dozen2: 3,
  dozen3: 3,
  column1: 3,
  column2: 3,
  column3: 3,
};

export const Roulette = () => {
  const { subtractFromBalance, addToBalance, addGameHistory, selectedCurrency, provablyFair, createGameVerification, getNextNonce } = useGameStore();
  const { playSound, playRouletteSpin, playWinSound, playLoseSound, playChipSound } = useSound();
  
  const [isSpinning, setIsSpinning] = useState(false);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [result, setResult] = useState<RouletteNumber | null>(null);
  const [bets, setBets] = useState<Bet[]>([]);
  const [selectedChip, setSelectedChip] = useState(10);
  const [message, setMessage] = useState('');
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);

  const chipValues = [1, 5, 10, 25, 100, 500, 1000];

  const placeBet = (type: Bet['type'], value?: number) => {
    if (isSpinning) return;
    playChipSound();
    
    const existingBetIndex = bets.findIndex(b => b.type === type && b.value === value);
    if (existingBetIndex >= 0) {
      setBets(prev => prev.map((b, i) => i === existingBetIndex ? { ...b, amount: b.amount + selectedChip } : b));
    } else {
      setBets(prev => [...prev, { type, value, amount: selectedChip }]);
    }
  };

  const clearBets = () => { 
    if (!isSpinning) {
      playSound('click');
      setBets([]); 
    } 
  };
  
  const undoLastBet = () => { 
    if (!isSpinning && bets.length > 0) {
      playSound('click');
      setBets(prev => prev.slice(0, -1)); 
    }
  };
  
  const totalBet = bets.reduce((sum, b) => sum + b.amount, 0);

  const handlePlay = () => {
    if (bets.length === 0 || totalBet === 0) return;
    if (!subtractFromBalance(totalBet, selectedCurrency)) return;

    playRouletteSpin();
    setIsSpinning(true);
    setMessage('');
    setResult(null);
    setShowVerification(false);

    const nonce = getNextNonce();
    const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, nonce);
    const winningNumber = NUMBERS[Math.floor(random * NUMBERS.length)];
    setResult(winningNumber);

    const numIndex = NUMBERS.indexOf(winningNumber);
    const segmentAngle = 360 / 37;
    const targetAngle = numIndex * segmentAngle + segmentAngle / 2;
    const spins = 5 + Math.floor(random * 3);
    const finalRotation = spins * 360 + (360 - targetAngle);
    
    setWheelRotation(prev => prev + finalRotation);

    setTimeout(() => {
      setIsSpinning(false);
      calculateWinnings(winningNumber);
    }, 5000);
  };

  const calculateWinnings = (winningNumber: RouletteNumber) => {
    let totalWin = 0;
    const isWinningRed = isRed(winningNumber);
    const isWinningEven = winningNumber !== 0 && winningNumber % 2 === 0;
    const isWinningLow = winningNumber >= 1 && winningNumber <= 18;
    const dozen = winningNumber === 0 ? 0 : Math.ceil(winningNumber / 12);

    const winningBets: string[] = [];

    bets.forEach(bet => {
      let win = 0;
      switch (bet.type) {
        case 'number': 
          if (bet.value === winningNumber) { 
            win = bet.amount * PAYOUTS.number; 
            winningBets.push(`Number ${bet.value}`); 
          } 
          break;
        case 'red': 
          if (isWinningRed) { 
            win = bet.amount * PAYOUTS.red; 
            winningBets.push('Red'); 
          } 
          break;
        case 'black': 
          if (!isWinningRed && winningNumber !== 0) { 
            win = bet.amount * PAYOUTS.black; 
            winningBets.push('Black'); 
          } 
          break;
        case 'even': 
          if (isWinningEven) { 
            win = bet.amount * PAYOUTS.even; 
            winningBets.push('Even'); 
          } 
          break;
        case 'odd': 
          if (winningNumber !== 0 && !isWinningEven) { 
            win = bet.amount * PAYOUTS.odd; 
            winningBets.push('Odd'); 
          } 
          break;
        case 'low': 
          if (isWinningLow) { 
            win = bet.amount * PAYOUTS.low; 
            winningBets.push('1-18'); 
          } 
          break;
        case 'high': 
          if (winningNumber >= 19) { 
            win = bet.amount * PAYOUTS.high; 
            winningBets.push('19-36'); 
          } 
          break;
        case 'dozen1': 
          if (dozen === 1) { 
            win = bet.amount * PAYOUTS.dozen1; 
            winningBets.push('1st 12'); 
          } 
          break;
        case 'dozen2': 
          if (dozen === 2) { 
            win = bet.amount * PAYOUTS.dozen2; 
            winningBets.push('2nd 12'); 
          } 
          break;
        case 'dozen3': 
          if (dozen === 3) { 
            win = bet.amount * PAYOUTS.dozen3; 
            winningBets.push('3rd 12'); 
          } 
          break;
        case 'column1': 
          if (winningNumber !== 0 && winningNumber % 3 === 1) { 
            win = bet.amount * PAYOUTS.column1; 
            winningBets.push('Column 1'); 
          } 
          break;
        case 'column2': 
          if (winningNumber !== 0 && winningNumber % 3 === 2) { 
            win = bet.amount * PAYOUTS.column2; 
            winningBets.push('Column 2'); 
          } 
          break;
        case 'column3': 
          if (winningNumber !== 0 && winningNumber % 3 === 0) { 
            win = bet.amount * PAYOUTS.column3; 
            winningBets.push('Column 3'); 
          } 
          break;
      }
      totalWin += win;
    });

    const netWin = totalWin - totalBet;

    if (totalWin > 0) {
      playWinSound();
      addToBalance(totalWin, selectedCurrency);
      setMessage(`You won ${netWin.toFixed(2)}!`);
    } else {
      playLoseSound();
      setMessage('No win this time');
    }

    const gameData = {
      winningNumber,
      bets: bets.map(b => ({ type: b.type, value: b.value, amount: b.amount })),
      winningBets,
    };

    const verification = createGameVerification(
      'Roulette',
      totalBet,
      selectedCurrency,
      totalWin > 0 ? 'win' : 'loss',
      Math.max(0, netWin),
      gameData
    );

    setCurrentVerification(verification);

    addGameHistory({
      game: 'Roulette',
      bet: totalBet,
      currency: selectedCurrency,
      result: totalWin > 0 ? 'win' : 'loss',
      amount: Math.abs(netWin),
      gameId: verification.gameId,
    });

    setBets([]);
  };

  const getBetAmount = (type: Bet['type'], value?: number) => 
    bets.find(b => b.type === type && b.value === value)?.amount || 0;

  const NumberCell = ({ num }: { num: RouletteNumber }) => {
    const betAmount = getBetAmount('number', num);
    const isRedNum = isRed(num);
    
    return (
      <button 
        onClick={() => placeBet('number', num)}
        disabled={isSpinning}
        className={cn(
          'relative w-full aspect-square flex items-center justify-center text-xs font-bold transition-all hover:scale-105 active:scale-95',
          num === 0 ? 'bg-[#00e701] text-black rounded-l-lg' : 
          isRedNum ? 'bg-[#ff4d4d] text-white hover:bg-[#ff6666]' : 
          'bg-[#1a1a1a] text-white hover:bg-[#333]',
          betAmount > 0 && 'ring-2 ring-[#fbbf24] z-10'
        )}
      >
        {num}
        {betAmount > 0 && (
          <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-[#fbbf24] rounded-full flex items-center justify-center text-[9px] text-black font-bold shadow">
            {betAmount >= 1000 ? 'k' : betAmount}
          </div>
        )}
      </button>
    );
  };

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full">
      {/* Controls */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4">
        {/* Chip Selection */}
        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Chip Value</label>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
            <button onClick={clearBets} disabled={isSpinning || bets.length === 0} className="text-[#b1bad3] hover:text-white disabled:opacity-50 p-1">
              <RotateCcw className="w-4 h-4" />
            </button>
            {chipValues.map((value) => (
              <button 
                key={value} 
                onClick={() => { playSound('click'); setSelectedChip(value); }} 
                disabled={isSpinning}
                className={cn(
                  'w-9 h-9 rounded-full flex items-center justify-center text-[10px] font-bold transition-all flex-shrink-0 disabled:opacity-50 hover:scale-110',
                  value === 1 && 'bg-white text-black border border-gray-300',
                  value === 5 && 'bg-[#ff4d4d] text-white border border-[#ff6666]',
                  value === 10 && 'bg-[#3b82f6] text-white border border-[#60a5fa]',
                  value === 25 && 'bg-[#00e701] text-black border border-[#4ade80]',
                  value === 100 && 'bg-[#1a1a1a] text-white border border-gray-600',
                  value === 500 && 'bg-purple-500 text-white border border-purple-400',
                  value === 1000 && 'bg-[#fbbf24] text-black border border-yellow-300',
                  selectedChip === value && 'ring-2 ring-white scale-110 shadow'
                )}
              >
                {value >= 1000 ? '1k' : value}
              </button>
            ))}
            <button onClick={undoLastBet} disabled={isSpinning || bets.length === 0} className="text-[#b1bad3] hover:text-white disabled:opacity-50 p-1">
              <Undo2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Total Bet */}
        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-1.5 block">Total Bet</label>
          <div className="bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 flex items-center justify-between">
            <span className="text-white font-mono text-lg">{totalBet.toFixed(2)}</span>
          </div>
        </div>

        {/* Spin Button */}
        <button 
          onClick={handlePlay} 
          disabled={isSpinning || bets.length === 0}
          className={cn(
            'w-full py-3 rounded-lg font-bold text-black transition-all mb-3', 
            isSpinning || bets.length === 0 ? 'bg-[#00e701]/50 cursor-not-allowed' : 
            'bg-[#00e701] hover:bg-[#00c701]'
          )}
        >
          {isSpinning ? 'Spinning...' : 'Spin'}
        </button>

        {/* Verification Button */}
        {currentVerification && !isSpinning && (
          <button
            onClick={() => setShowVerification(!showVerification)}
            className="w-full py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm hover:underline"
          >
            <Shield className="w-4 h-4" />
            Verify Fairness
          </button>
        )}
      </div>

      {/* Game Area */}
      <div className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 relative overflow-hidden">
        {/* Verification Panel */}
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-3">
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Game ID</p>
                  <p className="text-white text-sm font-mono break-all">{currentVerification.gameId}</p>
                </div>
                <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3">
                  <div className="flex items-center gap-2 text-[#00e701]">
                    <Check className="w-5 h-5" />
                    <span className="font-semibold">Verified</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Wheel */}
        <div className="flex justify-center mb-4">
          <div className="relative w-40 h-40 sm:w-48 sm:h-48">
            <div 
              className="absolute inset-0 rounded-full border-4 border-[#fbbf24] overflow-hidden shadow-lg"
              style={{ 
                transform: `rotate(${wheelRotation}deg)`, 
                transition: isSpinning ? 'transform 5s cubic-bezier(0.25, 0.1, 0.25, 1)' : 'none' 
              }}
            >
              {NUMBERS.map((num, i) => {
                const angle = (i * 360) / 37;
                const isRedNum = isRed(num);
                return (
                  <div 
                    key={num} 
                    className={cn(
                      'absolute w-full h-full', 
                      num === 0 ? 'bg-[#00e701]' : isRedNum ? 'bg-[#ff4d4d]' : 'bg-[#1a1a1a]'
                    )}
                    style={{ 
                      clipPath: `polygon(50% 50%, 50% 0%, ${50 + 50 * Math.cos((angle + 4.86) * Math.PI / 180)}% ${50 - 50 * Math.sin((angle + 4.86) * Math.PI / 180)}%)`, 
                      transform: `rotate(${angle}deg)` 
                    }}
                  >
                    <span 
                      className={cn(
                        'absolute text-[7px] font-bold', 
                        num === 0 ? 'text-black' : 'text-white'
                      )} 
                      style={{ left: '50%', top: '12%', transform: `translateX(-50%)` }}
                    >
                      {num}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="absolute inset-[30%] bg-[#1a2c38] rounded-full border-4 border-[#fbbf24] flex items-center justify-center z-10">
              {result !== null && (
                <span className={cn(
                  'text-2xl font-bold', 
                  result === 0 ? 'text-[#00e701]' : isRed(result) ? 'text-[#ff4d4d]' : 'text-white'
                )}>
                  {result}
                </span>
              )}
            </div>
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-2 border-r-2 border-t-4 border-l-transparent border-r-transparent border-t-[#fbbf24] z-20" />
          </div>
        </div>

        {/* Message */}
        {message && (
          <div className="text-center mb-3">
            <p className={cn(
              'text-lg font-bold', 
              message.includes('won') ? 'text-[#00e701]' : 'text-[#ff4d4d]'
            )}>
              {message}
            </p>
          </div>
        )}

        {/* Betting Table */}
        <div className="max-w-lg mx-auto">
          <div className="flex mb-0.5">
            <button 
              onClick={() => placeBet('number', 0)} 
              disabled={isSpinning}
              className={cn(
                'w-8 sm:w-10 bg-[#00e701] text-black font-bold flex items-center justify-center rounded-l-lg hover:brightness-110 transition-all disabled:opacity-50', 
                getBetAmount('number', 0) > 0 && 'ring-2 ring-[#fbbf24]'
              )}
            >
              0
            </button>
            <div className="flex-1 grid grid-cols-12 gap-0.5">
              {[...Array(3)].map((_, row) => (
                <div key={row} className="contents">
                  {NUMBERS.slice(1).filter((_, i) => i % 3 === row).map((num) => (
                    <NumberCell key={num} num={num} />
                  ))}
                </div>
              ))}
            </div>
            <div className="flex flex-col gap-0.5 ml-0.5">
              {['2:1', '2:1', '2:1'].map((label, i) => (
                <button 
                  key={i} 
                  onClick={() => placeBet(['column1', 'column2', 'column3'][i] as Bet['type'])} 
                  disabled={isSpinning}
                  className={cn(
                    'flex-1 px-2 bg-[#243b4d] text-white text-xs font-bold hover:bg-[#2f4553] transition-all disabled:opacity-50', 
                    getBetAmount(['column1', 'column2', 'column3'][i] as Bet['type']) > 0 && 'ring-2 ring-[#fbbf24]'
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-6 gap-0.5 mt-0.5">
            {['dozen1', 'dozen2', 'dozen3'].map((d, i) => (
              <button 
                key={d} 
                onClick={() => placeBet(d as Bet['type'])} 
                disabled={isSpinning}
                className={cn(
                  'bg-[#243b4d] text-white text-xs font-bold py-2 hover:bg-[#2f4553] transition-all col-span-2 disabled:opacity-50', 
                  getBetAmount(d as Bet['type']) > 0 && 'ring-2 ring-[#fbbf24]'
                )}
              >
                {['1st 12', '2nd 12', '3rd 12'][i]}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-6 gap-0.5 mt-0.5">
            {['low', 'even', 'red', 'black', 'odd', 'high'].map((t, i) => (
              <button 
                key={t} 
                onClick={() => placeBet(t as Bet['type'])} 
                disabled={isSpinning}
                className={cn(
                  'text-xs font-bold py-2 hover:brightness-110 transition-all disabled:opacity-50',
                  t === 'red' ? 'bg-[#ff4d4d] text-white' : 
                  t === 'black' ? 'bg-[#1a1a1a] text-white' : 
                  'bg-[#243b4d] text-white',
                  getBetAmount(t as Bet['type']) > 0 && 'ring-2 ring-[#fbbf24]'
                )}
              >
                {['1-18', 'EVEN', 'RED', 'BLACK', 'ODD', '19-36'][i]}
              </button>
            ))}
          </div>
        </div>

        {/* Provably Fair Badge */}
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
