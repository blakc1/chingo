import { useState, useRef } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { Shield, Check, X } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

// Plinko game with 1% house edge
// Ball drops through pegs and lands in multiplier slots
// Multipliers are set to give 1% house edge overall

// Multiplier configurations for different risk levels
const MULTIPLIERS = {
  low: [1.5, 1.2, 1.1, 1, 0.9, 0.8, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.5],
  medium: [3, 1.8, 1.2, 0.8, 0.6, 0.4, 0.3, 0.4, 0.6, 0.8, 1.2, 1.8, 3],
  high: [10, 4, 2, 1.2, 0.6, 0.3, 0.2, 0.3, 0.6, 1.2, 2, 4, 10],
};

const ROWS = 12;

export const Plinko = () => {
  const { subtractFromBalance, addToBalance, addGameHistory, selectedCurrency, provablyFair, createGameVerification, getNextNonce } = useGameStore();
  const { playSound, playWinSound, playLoseSound } = useSound();
  
  const [gameState, setGameState] = useState<'idle' | 'dropping' | 'finished'>('idle');
  const [betAmount, setBetAmount] = useState(10);
  const [riskLevel, setRiskLevel] = useState<'low' | 'medium' | 'high'>('medium');
  const [finalSlot, setFinalSlot] = useState<number | null>(null);
  const [winAmount, setWinAmount] = useState(0);
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);
  const [balls, setBalls] = useState<{ id: number; x: number; y: number; slot: number | null }[]>([]);
  
  const ballIdRef = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const multipliers = MULTIPLIERS[riskLevel];
  const numSlots = multipliers.length;

  const dropBall = async () => {
    if (gameState === 'dropping') return;
    if (!subtractFromBalance(betAmount, selectedCurrency)) return;

    playSound('click');
    setGameState('dropping');
    setShowVerification(false);

    const nonce = getNextNonce();
    const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, nonce);
    
    // Calculate final slot using binomial distribution
    // This simulates the ball bouncing left/right through pegs
    let slot = Math.floor(numSlots / 2);
    for (let i = 0; i < ROWS; i++) {
      const bounceRandom = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, nonce + i + 1);
      if (bounceRandom < 0.5) {
        slot = Math.max(0, slot - 1);
      } else {
        slot = Math.min(numSlots - 1, slot + 1);
      }
    }

    const multiplier = multipliers[slot];
    const win = multiplier >= 1;
    const winAmt = betAmount * multiplier;
    const profit = winAmt - betAmount;

    // Add ball to animation
    const ballId = ballIdRef.current++;
    setBalls(prev => [...prev, { id: ballId, x: 50, y: 0, slot: null }]);

    // Animate ball drop
    const container = containerRef.current;
    if (container) {
      const targetX = (slot + 0.5) * (100 / numSlots);

      // Animate
      await new Promise(resolve => setTimeout(resolve, 100));
      
      setBalls(prev => prev.map(b => 
        b.id === ballId ? { ...b, x: targetX, y: 85, slot } : b
      ));

      await new Promise(resolve => setTimeout(resolve, 800));
    }

    setFinalSlot(slot);
    setWinAmount(profit);
    setGameState('finished');

    // Remove ball after animation
    setTimeout(() => {
      setBalls(prev => prev.filter(b => b.id !== ballId));
    }, 1000);

    const gameData = {
      slot,
      multiplier,
      riskLevel,
      random,
      nonce,
    };

    if (win) {
      playWinSound();
      addToBalance(winAmt, selectedCurrency);
    } else {
      playLoseSound();
    }

    const verification = createGameVerification(
      'Plinko',
      betAmount,
      selectedCurrency,
      win ? 'win' : 'loss',
      profit,
      gameData
    );
    setCurrentVerification(verification);

    addGameHistory({
      game: 'Plinko',
      bet: betAmount,
      currency: selectedCurrency,
      result: win ? 'win' : 'loss',
      amount: profit,
      multiplier,
      gameId: verification.gameId,
    });
  };

  const handlePlayAgain = () => {
    setGameState('idle');
    setFinalSlot(null);
    setWinAmount(0);
    setShowVerification(false);
  };

  // Generate peg positions
  const generatePegs = () => {
    const pegs = [];
    for (let row = 2; row < ROWS + 2; row++) {
      const pegsInRow = row + 1;
      const rowWidth = (pegsInRow - 1) * 8;
      const startX = 50 - rowWidth / 2;
      
      for (let i = 0; i < pegsInRow; i++) {
        pegs.push({
          x: startX + i * 8,
          y: row * 6,
        });
      }
    }
    return pegs;
  };

  const pegs = generatePegs();

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full">
      {/* Controls */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4">
        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Bet Amount</label>
          <input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
            disabled={gameState === 'dropping'}
            className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono disabled:opacity-50"
          />
        </div>

        <div className="mb-4">
          <label className="text-[#557086] text-xs mb-2 block">Risk Level</label>
          <div className="grid grid-cols-3 gap-2">
            {(['low', 'medium', 'high'] as const).map((level) => (
              <button
                key={level}
                onClick={() => setRiskLevel(level)}
                disabled={gameState === 'dropping'}
                className={cn(
                  'py-2 rounded-lg text-sm font-medium capitalize transition-colors',
                  riskLevel === level
                    ? 'bg-[#00e701] text-black'
                    : 'bg-[#0f1923] text-[#b1bad3] hover:bg-[#243b4d]',
                  gameState === 'dropping' && 'opacity-50 cursor-not-allowed'
                )}
              >
                {level}
              </button>
            ))}
          </div>
        </div>

        {gameState === 'idle' && (
          <button 
            onClick={dropBall} 
            className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-colors"
          >
            Drop Ball
          </button>
        )}

        {gameState === 'dropping' && (
          <button 
            disabled 
            className="w-full py-3 bg-[#2f4553] text-white font-bold rounded-lg cursor-not-allowed"
          >
            Dropping...
          </button>
        )}

        {gameState === 'finished' && (
          <>
            <button 
              onClick={handlePlayAgain} 
              className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg mb-3 transition-colors"
            >
              Play Again
            </button>
            {currentVerification && (
              <button 
                onClick={() => setShowVerification(!showVerification)} 
                className="w-full py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm hover:bg-[#00e701]/10 rounded-lg transition-colors"
              >
                <Shield className="w-4 h-4" />
                Verify Fairness
              </button>
            )}
          </>
        )}

        {/* Multiplier preview */}
        <div className="mt-4">
          <p className="text-[#557086] text-xs mb-2">Multipliers</p>
          <div className="flex flex-wrap gap-1">
            {multipliers.map((m, i) => (
              <div 
                key={i} 
                className={cn(
                  'w-8 h-6 rounded text-xs font-mono flex items-center justify-center',
                  m >= 1 ? 'bg-[#00e701]/20 text-[#00e701]' : 'bg-[#ff4d4d]/20 text-[#ff4d4d]'
                )}
              >
                {m}x
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Area */}
      <div 
        ref={containerRef}
        className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 flex flex-col items-center justify-center relative overflow-hidden min-h-[400px]"
      >
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3 mb-4">
                <div className="flex items-center gap-2 text-[#00e701]">
                  <Check className="w-5 h-5" />
                  <span className="font-semibold">Verified</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Plinko board */}
        <div className="relative w-full max-w-sm aspect-[3/4]">
          {/* Pegs */}
          {pegs.map((peg, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-[#557086] rounded-full transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${peg.x}%`,
                top: `${peg.y}%`,
              }}
            />
          ))}

          {/* Balls */}
          {balls.map((ball) => (
            <div
              key={ball.id}
              className="absolute w-4 h-4 bg-[#00e701] rounded-full transform -translate-x-1/2 -translate-y-1/2 transition-all duration-700 ease-in-out z-10"
              style={{
                left: `${ball.x}%`,
                top: `${ball.y}%`,
              }}
            />
          ))}

          {/* Multiplier slots */}
          <div className="absolute bottom-0 left-0 right-0 flex">
            {multipliers.map((m, i) => (
              <div
                key={i}
                className={cn(
                  'flex-1 py-2 text-center text-xs font-mono font-bold border-t-2',
                  finalSlot === i 
                    ? m >= 1 
                      ? 'bg-[#00e701]/30 border-[#00e701] text-[#00e701]' 
                      : 'bg-[#ff4d4d]/30 border-[#ff4d4d] text-[#ff4d4d]'
                    : m >= 1 
                      ? 'bg-[#00e701]/10 border-[#00e701]/30 text-[#00e701]' 
                      : 'bg-[#ff4d4d]/10 border-[#ff4d4d]/30 text-[#ff4d4d]'
                )}
              >
                {m}x
              </div>
            ))}
          </div>
        </div>

        {/* Result display */}
        {gameState === 'finished' && finalSlot !== null && (
          <div className={cn(
            'mt-4 text-2xl font-bold',
            multipliers[finalSlot] >= 1 ? 'text-[#00e701]' : 'text-[#ff4d4d]'
          )}>
            {multipliers[finalSlot] >= 1 ? '+' : ''}{winAmount.toFixed(2)}
          </div>
        )}

        {/* Fairness indicator */}
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
