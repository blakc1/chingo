import { useState } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { type Card, type Suit, type Rank } from '@/types';
import { TrendingUp, TrendingDown, Shield, Check, X } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

const SUITS: Suit[] = ['hearts', 'diamonds', 'clubs', 'spades'];
const RANKS: Rank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

const SUIT_SYMBOLS: Record<Suit, string> = {
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
  spades: '♠',
};

const getCardValue = (rank: Rank): number => {
  if (rank === 'A') return 1;
  if (rank === 'K') return 13;
  if (rank === 'Q') return 12;
  if (rank === 'J') return 11;
  return parseInt(rank);
};

const createDeck = (): Card[] => {
  const deck: Card[] = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank, value: getCardValue(rank), faceUp: true });
    }
  }
  return deck;
};

const CardBack = () => (
  <div className="w-20 h-28 sm:w-24 sm:h-32 rounded-lg bg-gradient-to-br from-[#3b82f6] to-[#1d4ed8] border border-white/20 shadow-lg flex items-center justify-center">
    <span className="text-white/30 font-bold text-lg">B</span>
  </div>
);

const PlayingCard = ({ card }: { card: Card }) => {
  const isRed = card.suit === 'hearts' || card.suit === 'diamonds';

  return (
    <div className="w-20 h-28 sm:w-24 sm:h-32 bg-white rounded-lg shadow-lg border border-gray-200">
      <div className="w-full h-full flex flex-col justify-between p-1.5 relative">
        <div className="flex flex-col items-start leading-none">
          <span className={cn('text-sm font-bold', isRed ? 'text-red-500' : 'text-slate-900')}>
            {card.rank}
          </span>
          <span className={cn('text-xs', isRed ? 'text-red-500' : 'text-slate-900')}>
            {SUIT_SYMBOLS[card.suit]}
          </span>
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={cn('text-3xl sm:text-4xl', isRed ? 'text-red-500' : 'text-slate-900')}>
            {SUIT_SYMBOLS[card.suit]}
          </span>
        </div>
        <div className="flex flex-col items-end leading-none rotate-180">
          <span className={cn('text-sm font-bold', isRed ? 'text-red-500' : 'text-slate-900')}>
            {card.rank}
          </span>
          <span className={cn('text-xs', isRed ? 'text-red-500' : 'text-slate-900')}>
            {SUIT_SYMBOLS[card.suit]}
          </span>
        </div>
      </div>
    </div>
  );
};

export const HiLo = () => {
  const { subtractFromBalance, addToBalance, addGameHistory, selectedCurrency, provablyFair, createGameVerification, getNextNonce } = useGameStore();
  const { playSound, playWinSound, playLoseSound, playCashoutSound } = useSound();
  
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'finished'>('idle');
  const [currentCard, setCurrentCard] = useState<Card | null>(null);
  const [streak, setStreak] = useState(0);
  const [currentBet, setCurrentBet] = useState(0);
  const [betAmount, setBetAmount] = useState(10);
  const [message, setMessage] = useState('');
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);

  const shuffleDeck = (startNonce: number): Card[] => {
    const shuffled = createDeck();
    for (let i = shuffled.length - 1; i > 0; i--) {
      const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, startNonce + i);
      const j = Math.floor(random * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const initializeGame = () => {
    if (!subtractFromBalance(betAmount, selectedCurrency)) return;

    playSound('click');
    const nonce = getNextNonce();
    const newDeck = shuffleDeck(nonce);
    setCurrentCard(newDeck[0]);
    setStreak(0);
    setCurrentBet(betAmount);
    setMessage('');
    setShowVerification(false);
    setCurrentVerification(null);
    setGameState('playing');
  };

  const handleGuess = (choice: 'higher' | 'lower') => {
    if (gameState !== 'playing' || !currentCard) return;

    const nonce = getNextNonce();
    const newDeck = shuffleDeck(nonce);
    const nextCard = newDeck[0];

    const currentValue = currentCard.value;
    const nextValue = nextCard.value;
    const isCorrect = (choice === 'higher' && nextValue >= currentValue) || 
                      (choice === 'lower' && nextValue <= currentValue);

    if (isCorrect) {
      playWinSound();
      const newStreak = streak + 1;
      setStreak(newStreak);
      setCurrentCard(nextCard);
      setMessage(`Correct! Streak: ${newStreak}`);
    } else {
      playLoseSound();
      setMessage('Wrong!');
      setGameState('finished');

      const gameData = {
        currentCard: { rank: currentCard.rank, suit: currentCard.suit, value: currentCard.value },
        nextCard: { rank: nextCard.rank, suit: nextCard.suit, value: nextCard.value },
        choice,
        streak,
      };

      const verification = createGameVerification(
        'HiLo',
        currentBet,
        selectedCurrency,
        'loss',
        0,
        gameData
      );

      setCurrentVerification(verification);

      addGameHistory({
        game: 'HiLo',
        bet: currentBet,
        currency: selectedCurrency,
        result: 'loss',
        amount: 0,
        gameId: verification.gameId,
      });
    }
  };

  const handleCashout = () => {
    if (streak === 0) return;

    playCashoutSound();
    const multiplier = 1 + streak * 0.5;
    const winAmount = currentBet * multiplier;
    addToBalance(winAmount, selectedCurrency);
    setMessage(`Cashed out! Won ${(winAmount - currentBet).toFixed(2)}`);
    setGameState('finished');

    const gameData = {
      streak,
      multiplier,
    };

    const verification = createGameVerification(
      'HiLo',
      currentBet,
      selectedCurrency,
      'win',
      winAmount - currentBet,
      gameData
    );

    setCurrentVerification(verification);

    addGameHistory({
      game: 'HiLo',
      bet: currentBet,
      currency: selectedCurrency,
      result: 'win',
      amount: winAmount - currentBet,
      multiplier,
      gameId: verification.gameId,
    });
  };

  const handlePlayAgain = () => {
    setGameState('idle');
    setCurrentCard(null);
    setStreak(0);
    setMessage('');
    setShowVerification(false);
  };

  const higherProb = currentCard ? ((14 - currentCard.value) / 13 * 100) : 50;
  const lowerProb = currentCard ? ((currentCard.value - 1) / 13 * 100) : 50;

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full">
      {/* Controls */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4">
        {gameState === 'idle' && (
          <>
            <div className="mb-4">
              <label className="text-[#557086] text-xs mb-2 block">Bet Amount</label>
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono"
              />
            </div>
            <button onClick={initializeGame} className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg">
              Play
            </button>
          </>
        )}

        {gameState === 'playing' && (
          <>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <button onClick={() => handleGuess('higher')} className="bg-[#243b4d] hover:bg-[#00e701] hover:text-black text-white font-bold py-3 rounded-lg transition-all flex flex-col items-center">
                <TrendingUp className="w-4 h-4 mb-1" />
                <span>Higher</span>
                <span className="text-xs text-[#00e701]">{higherProb.toFixed(0)}%</span>
              </button>
              <button onClick={() => handleGuess('lower')} className="bg-[#243b4d] hover:bg-[#3b82f6] text-white font-bold py-3 rounded-lg transition-all flex flex-col items-center">
                <TrendingDown className="w-4 h-4 mb-1" />
                <span>Lower</span>
                <span className="text-xs text-[#3b82f6]">{lowerProb.toFixed(0)}%</span>
              </button>
            </div>
            {streak > 0 && (
              <button onClick={handleCashout} className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg animate-pulse">
                Cashout ({(1 + streak * 0.5).toFixed(2)}×)
              </button>
            )}
            <div className="mt-4 p-3 bg-[#0f1923] rounded-lg">
              <div className="flex justify-between text-sm">
                <span className="text-[#b1bad3]">Streak</span>
                <span className="text-white font-bold">{streak}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#b1bad3]">Multiplier</span>
                <span className="text-[#00e701] font-bold">{(1 + streak * 0.5).toFixed(2)}×</span>
              </div>
            </div>
          </>
        )}

        {gameState === 'finished' && (
          <>
            <button onClick={handlePlayAgain} className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg mb-3">
              Play Again
            </button>
            {currentVerification && (
              <button onClick={() => setShowVerification(!showVerification)} className="w-full py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm">
                <Shield className="w-4 h-4" />
                Verify Fairness
              </button>
            )}
          </>
        )}
      </div>

      {/* Game Area */}
      <div className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 flex flex-col items-center justify-center relative">
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3">
                <div className="flex items-center gap-2 text-[#00e701]">
                  <Check className="w-5 h-5" />
                  <span className="font-semibold">Verified</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {gameState === 'idle' ? (
          <div className="text-center">
            <CardBack />
            <p className="text-[#b1bad3] mt-4">Place a bet to start</p>
          </div>
        ) : (
          <>
            <div className="text-center mb-6">
              <p className="text-[#557086] text-xs mb-2">CURRENT CARD</p>
              {currentCard && <PlayingCard card={currentCard} />}
            </div>
            {message && (
              <p className={cn('text-xl font-bold', message.includes('Cashed') || message.includes('Correct') ? 'text-[#00e701]' : 'text-[#ff4d4d]')}>
                {message}
              </p>
            )}
          </>
        )}

        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
