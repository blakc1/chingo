import { useState, useCallback, useEffect, useRef } from 'react';
import { useGameStore, generateRandomFromSeed, type GameVerification } from '@/store/GameStore';
import { cn } from '@/lib/utils';
import { type Card, type Suit, type Rank } from '@/types';
import { Shield, Check, X, Info } from 'lucide-react';
import { useSound } from '@/hooks/useSound';

const SUITS: Suit[] = ['hearts', 'diamonds', 'clubs', 'spades'];
const RANKS: Rank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const NUM_DECKS = 8;

const SUIT_SYMBOLS: Record<Suit, string> = {
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
  spades: '♠',
};

const getCardValue = (rank: Rank): number => {
  if (rank === 'A') return 11;
  if (['J', 'Q', 'K'].includes(rank)) return 10;
  return parseInt(rank);
};

const createDeck = (): Card[] => {
  const deck: Card[] = [];
  for (let d = 0; d < NUM_DECKS; d++) {
    for (const suit of SUITS) {
      for (const rank of RANKS) {
        deck.push({ suit, rank, value: getCardValue(rank), faceUp: true });
      }
    }
  }
  return deck;
};

const calculateHandValue = (cards: Card[]): number => {
  let value = 0;
  let aces = 0;
  for (const card of cards) {
    if (card.rank === 'A') {
      aces++;
      value += 11;
    } else {
      value += card.value;
    }
  }
  while (value > 21 && aces > 0) {
    value -= 10;
    aces--;
  }
  return value;
};

const isSoft17 = (cards: Card[]): boolean => {
  let value = 0;
  let aces = 0;
  for (const card of cards) {
    if (card.rank === 'A') {
      aces++;
      value += 11;
    } else {
      value += card.value;
    }
  }
  while (value > 17 && aces > 0) {
    value -= 10;
    aces--;
  }
  return value === 17 && aces > 0;
};

const isBlackjack = (cards: Card[]): boolean => {
  return cards.length === 2 && calculateHandValue(cards) === 21;
};

interface AnimatedCard extends Card {
  id: string;
  isAnimating: boolean;
}

interface PlayerHand {
  cards: AnimatedCard[];
  bet: number;
  isStanding: boolean;
  isBusted: boolean;
  isBlackjack: boolean;
}

// Card Back Component - Blue Stake style
const CardBack = () => (
  <div className="w-full h-full rounded-lg bg-gradient-to-br from-[#3b82f6] to-[#1d4ed8] border border-white/20 shadow-lg flex items-center justify-center overflow-hidden relative">
    <div className="absolute inset-2 border border-white/10 rounded" />
    <div className="absolute inset-4 border border-white/5 rounded" />
    <span className="text-white/30 font-bold text-xl">B</span>
  </div>
);

// Playing Card Component - Clean Stake design
const PlayingCard = ({ card }: { card: AnimatedCard }) => {
  if (!card.faceUp) {
    return (
      <div className={cn(
        'w-14 h-20 sm:w-16 sm:h-22 rounded-lg shadow-lg transition-all duration-300',
        card.isAnimating && 'animate-deal-card'
      )}>
        <CardBack />
      </div>
    );
  }

  const isRed = card.suit === 'hearts' || card.suit === 'diamonds';

  return (
    <div className={cn(
      'w-14 h-20 sm:w-16 sm:h-22 bg-white rounded-lg shadow-lg border border-gray-200 transition-all duration-300',
      card.isAnimating && 'animate-deal-card'
    )}>
      <div className="w-full h-full flex flex-col justify-between p-1 relative">
        <div className="flex flex-col items-start leading-none">
          <span className={cn('text-xs font-bold', isRed ? 'text-red-500' : 'text-slate-900')}>
            {card.rank}
          </span>
          <span className={cn('text-[10px]', isRed ? 'text-red-500' : 'text-slate-900')}>
            {SUIT_SYMBOLS[card.suit]}
          </span>
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={cn('text-2xl sm:text-3xl', isRed ? 'text-red-500' : 'text-slate-900')}>
            {SUIT_SYMBOLS[card.suit]}
          </span>
        </div>
        <div className="flex flex-col items-end leading-none rotate-180">
          <span className={cn('text-xs font-bold', isRed ? 'text-red-500' : 'text-slate-900')}>
            {card.rank}
          </span>
          <span className={cn('text-[10px]', isRed ? 'text-red-500' : 'text-slate-900')}>
            {SUIT_SYMBOLS[card.suit]}
          </span>
        </div>
      </div>
    </div>
  );
};

export const Blackjack = () => {
  const {
    subtractFromBalance,
    addToBalance,
    addGameHistory,
    selectedCurrency,
    provablyFair,
    createGameVerification,
    startNewGameSession,
    endGameSession,
    getNextNonce,
  } = useGameStore();

  const { playCardSound, playFlipSound, playChipSound, playWinSound, playLoseSound, playBlackjack, playBust } = useSound();

  const [gameState, setGameState] = useState<'betting' | 'dealing' | 'playing' | 'dealerTurn' | 'finished'>('betting');
  const [playerHands, setPlayerHands] = useState<PlayerHand[]>([]);
  const [currentHandIndex, setCurrentHandIndex] = useState(0);
  const [dealerCards, setDealerCards] = useState<AnimatedCard[]>([]);
  const [currentBet, setCurrentBet] = useState(0);
  const [message, setMessage] = useState('');
  const [result, setResult] = useState<'win' | 'loss' | 'push' | 'blackjack' | null>(null);
  const [insuranceTaken, setInsuranceTaken] = useState(false);
  const [insuranceBet, setInsuranceBet] = useState(0);
  const [showVerification, setShowVerification] = useState(false);
  const [currentVerification, setCurrentVerification] = useState<GameVerification | null>(null);
  const [betAmount, setBetAmount] = useState(10);

  const deckRef = useRef<Card[]>([]);
  const sessionNonceRef = useRef(0);

  // Initialize deck with provably fair shuffle
  const initializeDeck = useCallback(() => {
    const newDeck = createDeck();
    const startNonce = getNextNonce();
    sessionNonceRef.current = startNonce;
    
    // Fisher-Yates shuffle
    for (let i = newDeck.length - 1; i > 0; i--) {
      const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, startNonce + i);
      const j = Math.floor(random * (i + 1));
      [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
    }
    
    deckRef.current = newDeck;
    return newDeck;
  }, [provablyFair.serverSeed, provablyFair.clientSeed, getNextNonce]);

  const drawCard = useCallback((faceUp: boolean = true): AnimatedCard => {
    const currentDeck = deckRef.current;
    if (currentDeck.length < 10) {
      const newDeck = createDeck();
      const newNonce = sessionNonceRef.current + 1000;
      sessionNonceRef.current = newNonce;
      for (let i = newDeck.length - 1; i > 0; i--) {
        const random = generateRandomFromSeed(provablyFair.serverSeed, provablyFair.clientSeed, newNonce + i);
        const j = Math.floor(random * (i + 1));
        [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
      }
      deckRef.current = newDeck;
      const card = newDeck.pop()!;
      return { ...card, faceUp, id: Math.random().toString(36).substr(2, 9), isAnimating: true };
    }
    
    const card = currentDeck.pop()!;
    deckRef.current = [...currentDeck];
    return { ...card, faceUp, id: Math.random().toString(36).substr(2, 9), isAnimating: true };
  }, [provablyFair.serverSeed, provablyFair.clientSeed]);

  const handlePlay = async () => {
    const amount = parseFloat(betAmount.toString());
    if (!subtractFromBalance(amount, selectedCurrency)) return;

    // Start new game session
    startNewGameSession('Blackjack');
    
    playChipSound();
    setCurrentBet(amount);
    setGameState('dealing');
    setMessage('');
    setResult(null);
    setPlayerHands([{ cards: [], bet: amount, isStanding: false, isBusted: false, isBlackjack: false }]);
    setCurrentHandIndex(0);
    setDealerCards([]);
    setInsuranceTaken(false);
    setInsuranceBet(0);
    setShowVerification(false);
    setCurrentVerification(null);

    initializeDeck();

    // Deal cards with delays
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const playerCard1 = drawCard(true);
    playCardSound();
    setPlayerHands(prev => [{ ...prev[0], cards: [playerCard1] }]);
    await new Promise(resolve => setTimeout(resolve, 300));

    const dealerCard1 = drawCard(true);
    playCardSound();
    setDealerCards([dealerCard1]);
    await new Promise(resolve => setTimeout(resolve, 300));

    const playerCard2 = drawCard(true);
    playCardSound();
    setPlayerHands(prev => [{ ...prev[0], cards: [prev[0].cards[0], playerCard2] }]);
    await new Promise(resolve => setTimeout(resolve, 300));

    const dealerCard2 = drawCard(false);
    playCardSound();
    setDealerCards(prev => [prev[0], dealerCard2]);
    await new Promise(resolve => setTimeout(resolve, 200));

    // Clear animations
    setPlayerHands(prev => [{
      ...prev[0],
      cards: prev[0].cards.map(c => ({ ...c, isAnimating: false }))
    }]);
    setDealerCards(prev => prev.map(c => ({ ...c, isAnimating: false })));

    setGameState('playing');
  };

  // Check for blackjack
  useEffect(() => {
    if (gameState === 'playing' && playerHands.length === 1 && playerHands[0].cards.length === 2 && dealerCards.length === 2) {
      const playerHand = playerHands[0];
      const playerHasBlackjack = isBlackjack(playerHand.cards);
      const dealerHasBlackjack = isBlackjack(dealerCards);

      if (dealerCards[0]?.rank === 'A' && !insuranceTaken) {
        return;
      }

      if (playerHasBlackjack || dealerHasBlackjack) {
        setTimeout(() => handleStand(), 500);
      }
    }
  }, [gameState, playerHands, dealerCards, insuranceTaken]);

  const handleInsurance = async (take: boolean) => {
    if (take) {
      const insuranceAmount = Math.floor(currentBet / 2);
      if (subtractFromBalance(insuranceAmount, selectedCurrency)) {
        playChipSound();
        setInsuranceTaken(true);
        setInsuranceBet(insuranceAmount);
      }
    } else {
      setInsuranceTaken(true);
    }

    const playerHasBlackjack = isBlackjack(playerHands[0].cards);
    const dealerHasBlackjack = isBlackjack(dealerCards);

    if (playerHasBlackjack || dealerHasBlackjack) {
      await handleStand();
    }
  };

  const handleHit = async () => {
    if (gameState !== 'playing') return;
    
    playCardSound();
    const newCard = drawCard(true);
    
    setPlayerHands(prev => {
      const newHands = [...prev];
      newHands[currentHandIndex] = {
        ...newHands[currentHandIndex],
        cards: [...newHands[currentHandIndex].cards, newCard],
      };
      return newHands;
    });

    setTimeout(() => {
      setPlayerHands(prev => {
        const hand = prev[currentHandIndex];
        const handValue = calculateHandValue(hand.cards);
        
        if (handValue > 21) {
          playBust();
          const newHands = [...prev];
          newHands[currentHandIndex] = { ...hand, isBusted: true };
          
          if (currentHandIndex < prev.length - 1) {
            setCurrentHandIndex(currentHandIndex + 1);
            return newHands;
          } else {
            setTimeout(() => handleStand(), 500);
            return newHands;
          }
        }
        
        const newHands = [...prev];
        newHands[currentHandIndex] = {
          ...hand,
          cards: hand.cards.map(c => ({ ...c, isAnimating: false }))
        };
        return newHands;
      });
    }, 400);
  };

  const handleStand = async () => {
    if (gameState !== 'playing') return;

    setPlayerHands(prev => {
      const newHands = [...prev];
      newHands[currentHandIndex] = { ...newHands[currentHandIndex], isStanding: true };
      return newHands;
    });

    if (currentHandIndex < playerHands.length - 1) {
      setCurrentHandIndex(prev => prev + 1);
      return;
    }

    setGameState('dealerTurn');

    // Reveal dealer's hidden card
    await new Promise(resolve => setTimeout(resolve, 500));
    playFlipSound();
    
    setDealerCards(prev =>
      prev.map((c, i) => (i === 1 ? { ...c, faceUp: true, isAnimating: true } : c))
    );

    setTimeout(() => {
      setDealerCards(prev => prev.map(c => ({ ...c, isAnimating: false })));
    }, 300);

    await new Promise(resolve => setTimeout(resolve, 500));

    // Dealer plays
    let currentDealerCards = dealerCards.map(c => ({ ...c, faceUp: true }));
    let currentDealerValue = calculateHandValue(currentDealerCards);

    while (currentDealerValue < 17 || (currentDealerValue === 17 && isSoft17(currentDealerCards))) {
      await new Promise(resolve => setTimeout(resolve, 500));
      playCardSound();
      
      const newCard = drawCard(true);
      setDealerCards(prev => [...prev, newCard]);
      currentDealerCards = [...currentDealerCards, newCard];
      currentDealerValue = calculateHandValue(currentDealerCards);

      setTimeout(() => {
        setDealerCards(prev =>
          prev.map((c, i) => i === prev.length - 1 ? { ...c, isAnimating: false } : c)
        );
      }, 300);

      await new Promise(resolve => setTimeout(resolve, 300));
    }

    determineWinner(currentDealerValue, currentDealerCards);
  };

  const handleDouble = async () => {
    const hand = playerHands[currentHandIndex];
    if (gameState !== 'playing' || hand.cards.length !== 2) return;
    if (!subtractFromBalance(hand.bet, selectedCurrency)) return;

    playChipSound();
    setPlayerHands(prev => {
      const newHands = [...prev];
      newHands[currentHandIndex] = { ...newHands[currentHandIndex], bet: hand.bet * 2 };
      return newHands;
    });

    playCardSound();
    const newCard = drawCard(true);
    
    setPlayerHands(prev => {
      const newHands = [...prev];
      newHands[currentHandIndex] = {
        ...newHands[currentHandIndex],
        cards: [...newHands[currentHandIndex].cards, newCard],
        isStanding: true,
      };
      return newHands;
    });

    setTimeout(() => {
      const handValue = calculateHandValue([...hand.cards, newCard]);
      if (handValue > 21) {
        playBust();
        setPlayerHands(prev => {
          const newHands = [...prev];
          newHands[currentHandIndex] = { ...newHands[currentHandIndex], isBusted: true };
          return newHands;
        });
      }
      handleStand();
    }, 500);
  };

  const handleSplit = async () => {
    const hand = playerHands[currentHandIndex];
    if (gameState !== 'playing' || hand.cards.length !== 2) return;
    if (hand.cards[0].value !== hand.cards[1].value) return;
    if (playerHands.length >= 4) return;
    if (!subtractFromBalance(hand.bet, selectedCurrency)) return;

    playChipSound();
    const card1 = hand.cards[0];
    const card2 = hand.cards[1];

    setPlayerHands(prev => {
      const newHands = [...prev];
      newHands[currentHandIndex] = {
        ...newHands[currentHandIndex],
        cards: [{ ...card1, isAnimating: false }],
      };
      newHands.splice(currentHandIndex + 1, 0, {
        cards: [{ ...card2, isAnimating: false }],
        bet: hand.bet,
        isStanding: false,
        isBusted: false,
        isBlackjack: false,
      });
      return newHands;
    });

    await new Promise(resolve => setTimeout(resolve, 300));
    playCardSound();
    const newCard1 = drawCard(true);
    
    setPlayerHands(prev => {
      const newHands = [...prev];
      newHands[currentHandIndex] = {
        ...newHands[currentHandIndex],
        cards: [...newHands[currentHandIndex].cards, newCard1],
      };
      return newHands;
    });

    setTimeout(() => {
      setPlayerHands(prev => {
        const newHands = [...prev];
        newHands[currentHandIndex] = {
          ...newHands[currentHandIndex],
          cards: newHands[currentHandIndex].cards.map(c => ({ ...c, isAnimating: false }))
        };
        return newHands;
      });
    }, 300);
  };

  const determineWinner = (finalDealerValue: number, finalDealerCards: Card[]) => {
    const dealerBust = finalDealerValue > 21;
    const dealerHasBlackjack = isBlackjack(finalDealerCards);

    let totalWin = 0;
    let totalBet = 0;

    playerHands.forEach(hand => {
      const handValue = calculateHandValue(hand.cards);
      const handBlackjack = isBlackjack(hand.cards);
      const handBust = handValue > 21;

      totalBet += hand.bet;

      if (handBlackjack && dealerHasBlackjack) {
        totalWin += hand.bet;
      } else if (handBlackjack) {
        totalWin += hand.bet * 2.5;
      } else if (dealerHasBlackjack) {
        if (insuranceTaken && insuranceBet > 0) {
          totalWin += insuranceBet * 3;
        }
      } else if (handBust) {
        // Loss
      } else if (dealerBust) {
        totalWin += hand.bet * 2;
      } else if (handValue > finalDealerValue) {
        totalWin += hand.bet * 2;
      } else if (handValue < finalDealerValue) {
        // Loss
      } else {
        totalWin += hand.bet;
      }
    });

    const netWin = totalWin - totalBet;

    if (netWin > 0) {
      if (playerHands.some(h => isBlackjack(h.cards))) {
        playBlackjack();
      } else {
        playWinSound();
      }
      addToBalance(totalWin, selectedCurrency);
      setResult('win');
      setMessage(`You won ${netWin.toFixed(2)}!`);
    } else if (netWin === 0) {
      setResult('push');
      setMessage('Push');
    } else {
      playLoseSound();
      setResult('loss');
      setMessage('Dealer wins');
    }

    setGameState('finished');
    endGameSession();

    // Create verification
    const gameData = {
      playerHands: playerHands.map(h => ({
        cards: h.cards.map(c => ({ rank: c.rank, suit: c.suit })),
        value: calculateHandValue(h.cards),
        bet: h.bet,
      })),
      dealerCards: finalDealerCards.map(c => ({ rank: c.rank, suit: c.suit })),
      dealerValue: finalDealerValue,
      insuranceTaken,
      insuranceBet,
    };

    const verification = createGameVerification(
      'Blackjack',
      totalBet,
      selectedCurrency,
      netWin > 0 ? 'win' : netWin === 0 ? 'push' : 'loss',
      Math.max(0, netWin),
      gameData
    );

    setCurrentVerification(verification);

    addGameHistory({
      game: 'Blackjack',
      bet: totalBet,
      currency: selectedCurrency,
      result: netWin > 0 ? 'win' : 'loss',
      amount: Math.abs(netWin),
      gameId: verification.gameId,
    });
  };

  const handleNewRound = () => {
    setGameState('betting');
    setPlayerHands([]);
    setCurrentHandIndex(0);
    setDealerCards([]);
    setCurrentBet(0);
    setMessage('');
    setResult(null);
    setInsuranceTaken(false);
    setInsuranceBet(0);
    setShowVerification(false);
    setCurrentVerification(null);
  };

  const currentHand = playerHands[currentHandIndex];
  const dealerValue = calculateHandValue(dealerCards.filter(c => c.faceUp));

  const canSplit = currentHand?.cards.length === 2 &&
    currentHand.cards[0].value === currentHand.cards[1].value &&
    playerHands.length < 4;

  const canDouble = currentHand?.cards.length === 2;
  const canInsurance = dealerCards[0]?.rank === 'A' && !insuranceTaken && playerHands[0]?.cards.length === 2;

  return (
    <div className="flex flex-col lg:flex-row gap-3 h-full p-3">
      {/* Controls Panel */}
      <div className="w-full lg:w-72 bg-[#1a2c38] rounded-xl border border-[#2f4553] p-4 flex flex-col">
        {/* Bet Amount */}
        {gameState === 'betting' && (
          <>
            <div className="mb-4">
              <label className="text-[#557086] text-xs font-medium mb-2 block">Bet Amount</label>
              <div className="relative">
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0f1923] border border-[#2f4553] rounded-lg px-4 py-3 text-white font-mono text-lg focus:outline-none focus:border-[#00e701] transition-colors"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  <button onClick={() => setBetAmount(betAmount / 2)} className="px-2 py-1 text-xs font-medium text-[#b1bad3] hover:text-white bg-[#243b4d] rounded">½</button>
                  <button onClick={() => setBetAmount(betAmount * 2)} className="px-2 py-1 text-xs font-medium text-[#b1bad3] hover:text-white bg-[#243b4d] rounded">2×</button>
                </div>
              </div>
            </div>
            <button
              onClick={handlePlay}
              className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              Deal
            </button>
          </>
        )}

        {/* Insurance Dialog */}
        {canInsurance && (
          <div className="bg-[#243b4d] rounded-lg p-4 mb-4 border border-[#fbbf24]">
            <p className="text-white text-sm mb-3 text-center">Insurance?</p>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => handleInsurance(true)} className="bg-[#fbbf24] hover:bg-[#f59e0b] text-black font-bold py-2 rounded-lg">
                Yes
              </button>
              <button onClick={() => handleInsurance(false)} className="bg-[#2f4553] hover:bg-[#3f5563] text-white font-bold py-2 rounded-lg">
                No
              </button>
            </div>
          </div>
        )}

        {/* Game Actions */}
        {gameState === 'playing' && !canInsurance && (
          <>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <button onClick={handleHit} className="bg-[#243b4d] hover:bg-[#00e701] hover:text-black text-white font-bold py-3 rounded-lg transition-all">
                Hit
              </button>
              <button onClick={handleStand} className="bg-[#243b4d] hover:bg-[#ff4d4d] text-white font-bold py-3 rounded-lg transition-all">
                Stand
              </button>
              <button onClick={handleDouble} disabled={!canDouble} className="bg-[#243b4d] hover:bg-[#3b82f6] text-white font-bold py-3 rounded-lg transition-all disabled:opacity-50">
                Double
              </button>
              <button onClick={handleSplit} disabled={!canSplit} className="bg-[#243b4d] hover:bg-[#8b5cf6] text-white font-bold py-3 rounded-lg transition-all disabled:opacity-50">
                Split
              </button>
            </div>
          </>
        )}

        {gameState === 'finished' && (
          <>
            <button onClick={handleNewRound} className="w-full py-3 bg-[#00e701] hover:bg-[#00c701] text-black font-bold rounded-lg transition-all">
              New Round
            </button>
            {currentVerification && (
              <button onClick={() => setShowVerification(!showVerification)} className="w-full mt-3 py-2 flex items-center justify-center gap-2 text-[#00e701] text-sm hover:underline">
                <Shield className="w-4 h-4" />
                Verify Fairness
              </button>
            )}
          </>
        )}

        {/* Rules */}
        <div className="mt-auto pt-4 border-t border-[#2f4553]">
          <div className="flex items-center gap-2 text-[#557086] text-xs mb-2">
            <Info className="w-3 h-3" />
            <span>Rules</span>
          </div>
          <ul className="text-[#557086] text-xs space-y-1">
            <li>• 8 decks, dealer stands soft 17</li>
            <li>• Blackjack pays 3:2</li>
            <li>• Double on any first two cards</li>
            <li>• Split up to 3 times</li>
          </ul>
        </div>
      </div>

      {/* Game Area */}
      <div className="flex-1 bg-[#0f1923] rounded-xl border border-[#2f4553] p-4 relative overflow-hidden min-h-[400px] flex flex-col">
        {/* Verification Panel */}
        {showVerification && currentVerification && (
          <div className="absolute inset-0 bg-[#0f1923]/95 z-50 p-6 overflow-auto">
            <div className="max-w-md mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00e701]" />
                  Provably Fair
                </h3>
                <button onClick={() => setShowVerification(false)} className="text-[#557086] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-3">
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Game ID</p>
                  <p className="text-white text-sm font-mono break-all">{currentVerification.gameId}</p>
                </div>
                <div className="bg-[#1a2c38] rounded-lg p-3">
                  <p className="text-[#557086] text-xs mb-1">Server Seed Hash</p>
                  <p className="text-white text-xs font-mono break-all">{currentVerification.serverSeedHash}</p>
                </div>
                <div className="bg-[#00e701]/10 border border-[#00e701] rounded-lg p-3">
                  <div className="flex items-center gap-2 text-[#00e701]">
                    <Check className="w-5 h-5" />
                    <span className="font-semibold">Verified</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Dealer Area */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-[#557086] text-xs font-semibold uppercase tracking-wider">Dealer</span>
            {dealerCards.some(c => c.faceUp) && (
              <span className="bg-[#243b4d] px-2 py-0.5 rounded text-white font-mono text-sm">{dealerValue}</span>
            )}
          </div>
          <div className="flex gap-1 justify-center">
            {dealerCards.map((card, i) => (
              <div key={card.id} className="relative" style={{ marginLeft: i > 0 ? '-24px' : '0', zIndex: i }}>
                <PlayingCard card={card} />
              </div>
            ))}
          </div>
        </div>

        {/* Table Text */}
        <div className="text-center py-4">
          <p className="text-[#557086] text-xs tracking-widest">BLACKJACK PAYS 3 TO 2</p>
          <p className="text-[#557086] text-xs tracking-widest mt-1">INSURANCE PAYS 2 TO 1</p>
        </div>

        {/* Message */}
        {message && (
          <div className="text-center py-2">
            <p className={cn(
              'text-xl font-bold',
              result === 'win' || result === 'blackjack' ? 'text-[#00e701]' :
              result === 'loss' ? 'text-[#ff4d4d]' :
              result === 'push' ? 'text-[#fbbf24]' : 'text-white'
            )}>
              {message}
            </p>
          </div>
        )}

        {/* Player Hands */}
        <div className="flex-1 flex flex-col items-center justify-center">
          {playerHands.map((hand, handIndex) => {
            const handValue = calculateHandValue(hand.cards);
            const isActive = handIndex === currentHandIndex && gameState === 'playing';

            return (
              <div key={handIndex} className={cn('flex flex-col items-center', isActive && 'ring-2 ring-[#00e701] rounded-lg p-2')}>
                <div className="flex gap-1 justify-center mb-2">
                  {hand.cards.map((card, i) => (
                    <div key={card.id} className="relative" style={{ marginLeft: i > 0 ? '-24px' : '0', zIndex: i }}>
                      <PlayingCard card={card} />
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[#557086] text-xs">HAND {handIndex + 1}</span>
                  {hand.cards.length > 0 && (
                    <span className={cn(
                      'px-2 py-0.5 rounded text-sm font-bold',
                      handValue > 21 ? 'bg-[#ff4d4d] text-white' :
                      handValue === 21 ? 'bg-[#00e701] text-black' :
                      'bg-[#243b4d] text-white'
                    )}>
                      {handValue}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Provably Fair Badge */}
        <div className="absolute bottom-3 right-3">
          <div className="flex items-center gap-1.5 text-[#557086] text-xs">
            <Shield className="w-3 h-3 text-[#00e701]" />
            <span>Fair</span>
          </div>
        </div>
      </div>
    </div>
  );
};
