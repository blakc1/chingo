import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

export type CurrencyType = 'gold' | 'blackout';

interface CurrencyBalance {
  gold: number;
  blackout: number;
}

interface PurchasePackage {
  id: string;
  name: string;
  goldCoins: number;
  blackoutCashBonus: number;
  price: number;
  popular?: boolean;
}

export const PURCHASE_PACKAGES: PurchasePackage[] = [
  { id: 'starter', name: 'Starter Pack', goldCoins: 50000, blackoutCashBonus: 5, price: 5 },
  { id: 'bronze', name: 'Bronze Pack', goldCoins: 110000, blackoutCashBonus: 11, price: 10 },
  { id: 'silver', name: 'Silver Pack', goldCoins: 280000, blackoutCashBonus: 28, price: 25, popular: true },
  { id: 'gold', name: 'Gold Pack', goldCoins: 600000, blackoutCashBonus: 60, price: 50 },
  { id: 'platinum', name: 'Platinum Pack', goldCoins: 1300000, blackoutCashBonus: 130, price: 100 },
  { id: 'diamond', name: 'Diamond Pack', goldCoins: 3500000, blackoutCashBonus: 350, price: 250 },
];

// Provably Fair System - Stake.us style
export interface ProvablyFairState {
  serverSeed: string;
  serverSeedHash: string;
  clientSeed: string;
  nonce: number;
}

export interface GameSession {
  id: string;
  gameType: string;
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  serverSeedHash: string;
  startTime: number;
}

export interface GameVerification {
  gameId: string;
  gameType: string;
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  serverSeedHash: string;
  betAmount: number;
  currency: CurrencyType;
  result: 'win' | 'loss' | 'push';
  payout: number;
  timestamp: number;
  gameData: Record<string, unknown>;
}

interface GameHistoryItem {
  game: string;
  bet: number;
  currency: CurrencyType;
  result: 'win' | 'loss';
  amount: number;
  multiplier?: number;
  timestamp: number;
  gameId?: string;
}

interface DailyBonus {
  lastClaimed: number | null;
  canClaim: boolean;
  timeUntilNext: number;
}

interface Transaction {
  id: string;
  type: 'purchase' | 'withdrawal' | 'bonus' | 'game_win' | 'game_loss';
  amount: number;
  currency: CurrencyType;
  description: string;
  timestamp: number;
  status: 'completed' | 'pending' | 'failed';
  gameId?: string;
}

interface GameState {
  // Currency
  balance: CurrencyBalance;
  selectedCurrency: CurrencyType;
  setSelectedCurrency: (currency: CurrencyType) => void;

  // Balance operations
  addToBalance: (amount: number, currency: CurrencyType) => void;
  subtractFromBalance: (amount: number, currency: CurrencyType) => boolean;
  canAfford: (amount: number, currency: CurrencyType) => boolean;

  // Daily bonus
  dailyBonus: DailyBonus;
  claimDailyBonus: () => boolean;
  dailyBonusTimeLeft: number;

  // Purchase
  purchasePackage: (packageId: string) => boolean;

  // Withdrawal
  requestWithdrawal: (amount: number, method: string, details: string) => boolean;

  // History
  gameHistory: GameHistoryItem[];
  addGameHistory: (item: Omit<GameHistoryItem, 'timestamp'>) => void;
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id' | 'timestamp'>) => void;

  // Navigation
  currentPage: string;
  setCurrentPage: (page: string) => void;

  // Provably Fair - Stake.us style
  provablyFair: ProvablyFairState;
  currentGameSession: GameSession | null;
  startNewGameSession: (gameType: string) => GameSession;
  endGameSession: () => void;
  generateNewClientSeed: () => void;
  setClientSeed: (seed: string) => void;
  rotateServerSeed: () => void;
  generateGameId: () => string;
  createGameVerification: (
    gameType: string,
    betAmount: number,
    currency: CurrencyType,
    result: 'win' | 'loss' | 'push',
    payout: number,
    gameData: Record<string, unknown>
  ) => GameVerification;
  gameVerifications: GameVerification[];
  verifyGame: (gameId: string) => boolean;
  
  // Game nonce for each bet
  getNextNonce: () => number;
}

const BONUS_COOLDOWN = 24 * 60 * 60 * 1000;
const DAILY_BONUS_COINS = 10000;
const DAILY_BONUS_CASH = 1;
const MIN_WITHDRAWAL = 50;

// Generate a cryptographically secure random seed
const generateSeed = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const array = new Uint8Array(64);
  crypto.getRandomValues(array);
  for (let i = 0; i < 64; i++) {
    result += chars.charAt(array[i] % chars.length);
  }
  return result;
};

// Simple hash for client-side
const hashSeed = (seed: string): string => {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16).padStart(64, '0');
};

// Generate random number from seed (provably fair) - Stake.us style
export const generateRandomFromSeed = (serverSeed: string, clientSeed: string, nonce: number): number => {
  const combined = `${serverSeed}:${clientSeed}:${nonce}`;
  let hash = 0;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  const random = (Math.abs(hash) % 100000000) / 100000000;
  return random;
};

const GameContext = createContext<GameState | null>(null);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const loadSavedState = () => {
    try {
      const saved = localStorage.getItem('blackout_casino_state');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          balance: parsed.balance || { gold: 50000, blackout: 5 },
          lastBonusClaim: parsed.lastBonusClaim || null,
          transactions: parsed.transactions || [],
          provablyFair: parsed.provablyFair || null,
          gameVerifications: parsed.gameVerifications || [],
        };
      }
    } catch {
      // Ignore parse errors
    }
    return {
      balance: { gold: 50000, blackout: 5 },
      lastBonusClaim: null,
      transactions: [],
      provablyFair: null,
      gameVerifications: [],
    };
  };

  const savedState = loadSavedState();

  const [balance, setBalance] = useState<CurrencyBalance>(savedState.balance);
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyType>('gold');
  const [lastBonusClaim, setLastBonusClaim] = useState<number | null>(savedState.lastBonusClaim);
  const [gameHistory, setGameHistory] = useState<GameHistoryItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>(savedState.transactions);
  const [currentPage, setCurrentPage] = useState('casino');
  const [dailyBonusTimeLeft, setDailyBonusTimeLeft] = useState(0);
  const [currentGameSession, setCurrentGameSession] = useState<GameSession | null>(null);

  // Provably Fair State - Stake.us style
  const [provablyFair, setProvablyFair] = useState<ProvablyFairState>(() => {
    if (savedState.provablyFair) {
      return savedState.provablyFair;
    }
    const serverSeed = generateSeed();
    return {
      serverSeed,
      serverSeedHash: hashSeed(serverSeed),
      clientSeed: generateSeed(),
      nonce: 0,
    };
  });

  const [gameVerifications, setGameVerifications] = useState<GameVerification[]>(savedState.gameVerifications);

  // Save to localStorage
  useEffect(() => {
    const stateToSave = {
      balance,
      lastBonusClaim,
      transactions,
      provablyFair,
      gameVerifications,
    };
    localStorage.setItem('blackout_casino_state', JSON.stringify(stateToSave));
  }, [balance, lastBonusClaim, transactions, provablyFair, gameVerifications]);

  // Live timer for daily bonus
  useEffect(() => {
    const updateTimer = () => {
      if (!lastBonusClaim) {
        setDailyBonusTimeLeft(0);
        return;
      }
      const now = Date.now();
      const timeSinceLastClaim = now - lastBonusClaim;
      const timeLeft = Math.max(0, BONUS_COOLDOWN - timeSinceLastClaim);
      setDailyBonusTimeLeft(timeLeft);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [lastBonusClaim]);

  // Calculate daily bonus status
  const dailyBonus: DailyBonus = (() => {
    if (!lastBonusClaim) {
      return { lastClaimed: null, canClaim: true, timeUntilNext: 0 };
    }
    const canClaim = dailyBonusTimeLeft === 0;
    return { lastClaimed: lastBonusClaim, canClaim, timeUntilNext: dailyBonusTimeLeft };
  })();

  const addToBalance = useCallback((amount: number, currency: CurrencyType) => {
    setBalance(prev => ({
      ...prev,
      [currency]: prev[currency] + amount,
    }));
  }, []);

  const subtractFromBalance = useCallback((amount: number, currency: CurrencyType): boolean => {
    if (balance[currency] >= amount) {
      setBalance(prev => ({
        ...prev,
        [currency]: prev[currency] - amount,
      }));
      return true;
    }
    return false;
  }, [balance]);

  const canAfford = useCallback((amount: number, currency: CurrencyType): boolean => {
    return balance[currency] >= amount;
  }, [balance]);

  const claimDailyBonus = useCallback((): boolean => {
    if (!dailyBonus.canClaim) {
      return false;
    }

    const now = Date.now();
    setLastBonusClaim(now);

    setBalance(prev => ({
      gold: prev.gold + DAILY_BONUS_COINS,
      blackout: prev.blackout + DAILY_BONUS_CASH,
    }));

    addTransaction({
      type: 'bonus',
      amount: DAILY_BONUS_COINS,
      currency: 'gold',
      description: 'Daily Login Bonus - Gold Coins',
      status: 'completed',
    });

    addTransaction({
      type: 'bonus',
      amount: DAILY_BONUS_CASH,
      currency: 'blackout',
      description: 'Daily Login Bonus - BlackoutCash',
      status: 'completed',
    });

    return true;
  }, [dailyBonus.canClaim]);

  const purchasePackage = useCallback((packageId: string): boolean => {
    const pkg = PURCHASE_PACKAGES.find(p => p.id === packageId);
    if (!pkg) return false;

    setBalance(prev => ({
      gold: prev.gold + pkg.goldCoins,
      blackout: prev.blackout + pkg.blackoutCashBonus,
    }));

    addTransaction({
      type: 'purchase',
      amount: pkg.goldCoins,
      currency: 'gold',
      description: `Purchased ${pkg.name} - Gold Coins`,
      status: 'completed',
    });

    addTransaction({
      type: 'purchase',
      amount: pkg.blackoutCashBonus,
      currency: 'blackout',
      description: `Purchased ${pkg.name} - BlackoutCash Bonus`,
      status: 'completed',
    });

    return true;
  }, []);

  const requestWithdrawal = useCallback((amount: number, method: string, details: string): boolean => {
    if (amount < MIN_WITHDRAWAL) {
      return false;
    }
    if (balance.blackout < amount) {
      return false;
    }

    setBalance(prev => ({
      ...prev,
      blackout: prev.blackout - amount,
    }));

    addTransaction({
      type: 'withdrawal',
      amount,
      currency: 'blackout',
      description: `Withdrawal via ${method} - ${details}`,
      status: 'pending',
    });

    return true;
  }, [balance.blackout]);

  const addTransaction = useCallback((transaction: Omit<Transaction, 'id' | 'timestamp'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Math.random().toString(36).substring(2, 15),
      timestamp: Date.now(),
    };
    setTransactions(prev => [newTransaction, ...prev].slice(0, 100));
  }, []);

  const addGameHistory = useCallback((item: Omit<GameHistoryItem, 'timestamp'>) => {
    const newItem: GameHistoryItem = {
      ...item,
      timestamp: Date.now(),
    };
    setGameHistory(prev => [newItem, ...prev].slice(0, 50));

    addTransaction({
      type: item.result === 'win' ? 'game_win' : 'game_loss',
      amount: item.amount,
      currency: item.currency,
      description: `${item.game} - ${item.result === 'win' ? 'Win' : 'Loss'}`,
      status: 'completed',
      gameId: item.gameId,
    });
  }, [addTransaction]);

  // Provably Fair Functions - Stake.us style
  const generateNewClientSeed = useCallback(() => {
    setProvablyFair(prev => ({
      ...prev,
      clientSeed: generateSeed(),
      nonce: 0,
    }));
  }, []);

  const setClientSeed = useCallback((seed: string) => {
    setProvablyFair(prev => ({
      ...prev,
      clientSeed: seed,
      nonce: 0,
    }));
  }, []);

  const rotateServerSeed = useCallback(() => {
    const newServerSeed = generateSeed();
    setProvablyFair(prev => ({
      ...prev,
      serverSeed: newServerSeed,
      serverSeedHash: hashSeed(newServerSeed),
      nonce: 0,
    }));
  }, []);

  const generateGameId = useCallback((): string => {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `BO-${timestamp}-${random}`;
  }, []);

  // Start a new game session - this creates a fresh game context
  const startNewGameSession = useCallback((gameType: string): GameSession => {
    const session: GameSession = {
      id: generateGameId(),
      gameType,
      serverSeed: provablyFair.serverSeed,
      clientSeed: provablyFair.clientSeed,
      nonce: provablyFair.nonce,
      serverSeedHash: provablyFair.serverSeedHash,
      startTime: Date.now(),
    };
    setCurrentGameSession(session);
    return session;
  }, [provablyFair, generateGameId]);

  // End current game session
  const endGameSession = useCallback(() => {
    setCurrentGameSession(null);
  }, []);

  // Get next nonce for betting within a session
  const getNextNonce = useCallback((): number => {
    const nextNonce = provablyFair.nonce;
    setProvablyFair(prev => ({ ...prev, nonce: prev.nonce + 1 }));
    return nextNonce;
  }, [provablyFair.nonce]);

  const createGameVerification = useCallback((
    gameType: string,
    betAmount: number,
    currency: CurrencyType,
    result: 'win' | 'loss' | 'push',
    payout: number,
    gameData: Record<string, unknown>
  ): GameVerification => {
    const gameId = currentGameSession?.id || generateGameId();
    const verification: GameVerification = {
      gameId,
      gameType,
      serverSeed: provablyFair.serverSeed,
      clientSeed: provablyFair.clientSeed,
      nonce: currentGameSession?.nonce || provablyFair.nonce,
      serverSeedHash: provablyFair.serverSeedHash,
      betAmount,
      currency,
      result,
      payout,
      timestamp: Date.now(),
      gameData,
    };

    setGameVerifications(prev => [verification, ...prev].slice(0, 100));
    
    return verification;
  }, [provablyFair, currentGameSession, generateGameId]);

  const verifyGame = useCallback((gameId: string): boolean => {
    const verification = gameVerifications.find(v => v.gameId === gameId);
    if (!verification) return false;

    // Verify that the server seed hash matches
    const computedHash = hashSeed(verification.serverSeed);
    return computedHash === verification.serverSeedHash;
  }, [gameVerifications]);

  return (
    <GameContext.Provider
      value={{
        balance,
        selectedCurrency,
        setSelectedCurrency,
        addToBalance,
        subtractFromBalance,
        canAfford,
        dailyBonus,
        claimDailyBonus,
        dailyBonusTimeLeft,
        purchasePackage,
        requestWithdrawal,
        gameHistory,
        addGameHistory,
        transactions,
        addTransaction,
        currentPage,
        setCurrentPage,
        provablyFair,
        currentGameSession,
        startNewGameSession,
        endGameSession,
        generateNewClientSeed,
        setClientSeed,
        rotateServerSeed,
        generateGameId,
        createGameVerification,
        gameVerifications,
        verifyGame,
        getNextNonce,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGameStore = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGameStore must be used within a GameProvider');
  }
  return context;
};

export { MIN_WITHDRAWAL, DAILY_BONUS_COINS, DAILY_BONUS_CASH };
