import { useState } from 'react';
import { GameProvider } from '@/store/GameStore';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { Blackjack } from '@/games/Blackjack';
import { Roulette } from '@/games/Roulette';
import { HiLo } from '@/games/HiLo';
import { Limbo } from '@/games/Limbo';
import { Crash } from '@/games/Crash';
import { Plinko } from '@/games/Plinko';
import { Mines } from '@/games/Mines';
import { DailyBonus } from '@/pages/DailyBonus';
import { Wallet } from '@/pages/Wallet';
import { Purchase } from '@/pages/Purchase';
import { Withdrawal } from '@/pages/Withdrawal';
import { Terms } from '@/pages/Terms';
import { Privacy } from '@/pages/Privacy';
import { Support } from '@/pages/Support';
import { useGameStore } from '@/store/GameStore';
import { cn } from '@/lib/utils';

// Main App Content Component
const AppContent = () => {
  const [currentGame, setCurrentGame] = useState('blackjack');
  const { currentPage } = useGameStore();

  const renderContent = () => {
    switch (currentPage) {
      case 'casino':
        switch (currentGame) {
          case 'blackjack':
            return <Blackjack />;
          case 'roulette':
            return <Roulette />;
          case 'hilo':
            return <HiLo />;
          case 'limbo':
            return <Limbo />;
          case 'crash':
            return <Crash />;
          case 'plinko':
            return <Plinko />;
          case 'mines':
            return <Mines />;
          default:
            return <Blackjack />;
        }
      case 'dailybonus':
        return <DailyBonus />;
      case 'wallet':
        return <Wallet />;
      case 'purchase':
        return <Purchase />;
      case 'withdrawal':
        return <Withdrawal />;
      case 'terms':
        return <Terms />;
      case 'privacy':
        return <Privacy />;
      case 'support':
        return <Support />;
      default:
        return <Blackjack />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0f1923]">
      {/* Header */}
      <Header currentGame={currentGame} />

      {/* Sidebar */}
      <Sidebar currentGame={currentGame} onGameSelect={setCurrentGame} />

      {/* Main Content */}
      <main className={cn(
        "pt-14 min-h-screen transition-all duration-300",
        "lg:ml-60"
      )}>
        <div className="p-4 h-[calc(100vh-3.5rem)]">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

// Root App Component
function App() {
  return (
    <GameProvider>
      <AppContent />
    </GameProvider>
  );
}

export default App;
